# DEADLINE 3.5 public runner

27 public tasks; 24 scored. The default client runs v3.5.

`python client/deadline_client.py --openrouter --model YOUR_MODEL --dry-run`

Remove --dry-run to start. Set provider effort using --params; --effort labels it.
Use --max-spend USD for a client estimate cap, --validate FILE to check completeness,
and --package FILE to produce the attachment and pinned metadata for submission.
Answers and token receipts are retained; this client contains no private grader.
The separate v3.6 development archive and versioned data are in the site repository.
