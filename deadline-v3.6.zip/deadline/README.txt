DEADLINE 3.6 development preview

No certified results have been published. Default client remains 3.5.
Select new prompts explicitly with --benchmark-version 3.6.
Example: python client/deadline_client.py --benchmark-version 3.6 --openrouter --model YOUR_MODEL --dry-run
Use --params for the actual provider effort setting; --effort is only a label.
Use --extend OLD.json --out NEW.json to carry fully matching prompt/settings receipts.
Validate and package with --validate FILE and --package FILE. Private graders are not included.
