# O2 · Strategy arena ("Outpost") · small

Write a bot for a two-player grid war game. It plays full matches against five public ladder bots on maps you have
never seen. The faster you destroy the enemy base, the better.

## Score
Each hidden instance is one match: a fresh map (16x16, 200 turns), one opponent from `bots.OPPONENTS`
(turtle, rusher, economist, balanced, marshal; six matches each) and a side (player 0 or 1).
- `you` = `referee.cost(final_state, your_side)`. A win costs the turn when the enemy base fell. Anything else costs
  `T * (1 + enemy base HP left/50 + own base HP lost/50)`, plus the turns that were left if your base fell. So any win
  beats any non-win. Lower is better.
- `floor` = the cost of the idle bot (`bots.Idle`) in the same seat. `ref` = the LOWEST cost any ladder bot
  (turtle, rusher, economist, balanced, marshal) gets in the same seat against the same opponent on the same map.
- Score per match = `log(floor/you) / log(floor/ref)`, never below -0.15. Idle scores 0, the best ladder bot for
  that match scores 1, and better than every ladder bot scores above 1. There is no maximum. A forfeit scores -0.15.
- The task score is the mean over 30 matches. The maps are made the same way as in `examples.json`, and they are
  minted only after your run ends.

## Interface
- Write `answers/solution.py` with `act(view)`, which returns your orders for one turn. `view` is
  `referee.view(state, you)`. You get the whole board: units, HP, carried crystals, banks and the turn number.
- Orders are `{"units": {"<unit id>": order}, "spawn": null|"w"|"s"}`. An order is `["move", d]`, `["attack", d]`,
  `["harvest", d]` or `["stay"]`, with d one of U D L R. Units you leave out stay where they are.
- Your module is loaded fresh for each match. Module-level state lives for that one match.
- A bad order object, or an exception inside `act`, loses that whole turn's orders. It is not a forfeit.
- A forfeit (-0.15) happens when your process crashes, prints a broken reply, takes more than 2.0 seconds on one
  turn, or uses more than 50 seconds of thinking over the whole match. Loading your module is not counted.
- Matches run in the grader's sandbox: Python 3.12 standard library only, no network, one CPU and 512 MB.

## Rules
`referee.py` is the exact rule set the grader runs. If this summary and the code ever differ, the code wins.
- Map: `#` walls; crystal cells with an amount; two bases. Units stand only on `.` cells with no crystal and no base.
- Start: each base has 50 HP, the bank holds 10, and each side has 2 workers.
- Worker (`w`): costs 5, 6 HP, attack 1. It harvests 1 crystal per turn from the next cell and carries up to 5. It puts
  its load into the bank at the end of any turn it stands next to its own base.
- Soldier (`s`): costs 8, 10 HP, attack 3.
- `"spawn"` buys one unit. It takes the first free cell next to your base in the order U, R, D, L for player 0, or
  D, L, U, R for player 1 (the same order turned 180 degrees). It is paid only if it is placed.
- Each turn resolves in this order:
  1. Attacks: all damage is summed and applied at once, then dead units are removed. Attacking the enemy base hurts it.
  2. Harvests. If more workers harvest one cell this turn than it has crystals left, none of them get any.
  3. Moves: a move fails into a wall, a crystal or a base, when two units want the same cell, when two units swap, or
     when the target holds a unit that does not itself move away.
  4. Deposits.
  5. Spawns (player 0 first).
  6. A base at 0 HP or less falls and the game ends. The game also ends after turn 200.

## Tools in this folder
- `referee.py` holds the exact rules (`new_game`, `step`, `view`, `check_orders`, `cost`, `play`).
- `bots.py` holds the ladder bots you will face. They are deterministic and their source is public.
- `play.py` plays your bot on every example and prints the exact grader score. Run `python play.py`.
- `examples.json` holds public maps, each with its opponent, side, floor, ref, the bot that set ref (`ref_bot`) and
  every ladder bot's cost (`ladder`).
