# O7 · Compression · game replay JSON lines

Write a compressor and decompressor for one kind of structured text file: game replay JSON lines. Make the compressed files as SMALL
as you can, and get every file back exactly.

## Score
For each of 30 hidden files:
- `you` = the size in bytes of your blob, plus the size of your `solution.py` divided by 30. Your program's own
  size counts, shared over the files.
- `floor` = the same for "no compression": the UTF-8 bytes of the file.
- `ref` = the same for the best standard compressor per file: the smallest of
  `lzma.compress(data, preset=9 | lzma.PRESET_EXTREME, check=lzma.CHECK_NONE)`, `bz2.compress(data, 9)` and
  `zlib.compress(data, 9)` on the UTF-8 bytes, plus a one-byte tag.

The rules:
- A failed or inexact round trip, an exception, a blob larger than 2 x the file plus 1000 bytes, or a group out of
  time scores -0.15.
- Otherwise the score is `log(floor/you) / log(floor/ref)`, never below -0.15. No compression scores about 0, the best
  standard compressor scores about 1, and smaller scores more. There is no maximum.
- The task score is the mean over the hidden files. They are made the same way as the examples, and they are minted
  only after your run ends.

## Interface
- `answers/solution.py` defines `compress(text: str) -> bytes` and `decompress(blob: bytes) -> str`.
- The grader runs `compress` on a group of 5 files in one sandbox process.
- Later it runs `decompress` on the blobs in a NEW sandbox process. That process gets only the blob: no globals, files
  or state carry over.
- Use Python 3.12, standard library only (zlib, bz2, lzma and the rest are allowed), one CPU and 512 MB of memory.
  There is no network.
- Each phase of each group has 150 seconds.
- Files are about 110-180 KB of text, made by the same hidden generator as `examples.json`. Field values, counts, ids, timings
  and noise all change from file to file.

## Tools in this folder
- `check.py` compresses each example, decompresses it in a fresh Python process, checks the round trip, and prints
  your exact sizes and scores.
- `examples.json` holds public files, each with its `floor` and `ref` sizes.
