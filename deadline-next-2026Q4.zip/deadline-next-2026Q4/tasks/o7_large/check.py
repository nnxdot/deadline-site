import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

"""python check.py [answers/solution.py]: for each example, compresses in this process, then decompresses in a NEW
Python process that only gets the blob (as the grader does), checks the round trip, and prints sizes and scores."""
import json, os, subprocess, sys, tempfile
path = sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py'
import importlib.util
spec = importlib.util.spec_from_file_location('solution', path); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
code_bytes = os.path.getsize(path); scores = []
UNPACK = "import importlib.util,sys\nspec=importlib.util.spec_from_file_location('solution',sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\nblob=open(sys.argv[2],'rb').read()\nt=m.decompress(blob)\nassert type(t) is str\nopen(sys.argv[3],'w',encoding='utf-8',newline='').write(t)\n"
for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
    with tempfile.TemporaryDirectory() as tmp:
        try:
            blob = mod.compress(e['text']); assert type(blob) is bytes
            open(os.path.join(tmp, 'b'), 'wb').write(blob)
            subprocess.run([sys.executable, '-c', UNPACK, os.path.abspath(path), os.path.join(tmp, 'b'), os.path.join(tmp, 't')], check=True)
            ok = open(os.path.join(tmp, 't'), encoding='utf-8', newline='').read() == e['text']
        except Exception as exc: ok, blob = False, b''; print('example %d: error %s' % (i, type(exc).__name__))
    you = len(blob) + code_bytes / 30 if ok else None
    s = score(e['floor'], e['ref'], you); scores.append(s)
    print('example %d: %d chars, floor %.0f, ref %.0f, you %s, score %.3f%s' % (i, len(e['text']), e['floor'], e['ref'],
          '%.0f' % you if you else None, s, '' if ok else ' (round trip failed)'))
print('mean score %.3f' % (sum(scores) / len(scores)))
