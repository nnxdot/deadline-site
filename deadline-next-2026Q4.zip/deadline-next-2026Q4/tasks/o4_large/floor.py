def solve(city):
    """Jobs (a drop-off, or a pickup with its delivery) in order of their first window closing. Each job joins the
    end of the newest van if that van stays feasible, else it starts a new van."""
    stops = {s['id']: s for s in city['stops']}
    def d(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1])
    def feasible(route):
        load = sum(stops[i]['load'] for i in route if stops[i]['kind'] == 'drop')
        if load > city['capacity']: return False
        t, pos = 0, city['depot']
        for i in route:
            s = stops[i]; t += d(pos, s['xy']); pos = s['xy']
            t = max(t, s['window'][0])
            if t > s['window'][1]: return False
            load += s['load'] if s['kind'] == 'pickup' else -s['load']
            if load > city['capacity']: return False
            t += s['service']
        return t + d(pos, city['depot']) <= city['shift']
    jobs = [[s['id']] if s['kind'] == 'drop' else [s['id'], s['pair']] for s in city['stops'] if s['kind'] in ('drop', 'pickup')]
    jobs.sort(key=lambda j: (stops[j[0]]['window'][1], j[0]))
    routes = []
    for job in jobs:
        if routes and feasible(routes[-1] + job): routes[-1] = routes[-1] + job
        else: routes.append(list(job))
    return routes
