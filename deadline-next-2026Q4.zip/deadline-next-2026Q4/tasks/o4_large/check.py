def dist(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1])
def cost(city, answer):
    """(fees + distance, None) if every rule holds, else (None, the first broken rule)."""
    stops = {s['id']: s for s in city['stops']}
    if type(answer) is not list or not answer: return None, 'answer must be a non-empty list of routes'
    seen, total = set(), 0
    for n, route in enumerate(answer):
        if type(route) is not list or not route: return None, 'route %d must be a non-empty list of stop ids' % n
        for i in route:
            if type(i) is not int or i not in stops: return None, 'route %d: unknown stop id %r' % (n, i)
            if i in seen: return None, 'stop %d is visited twice' % i
            seen.add(i)
        where = {i: k for k, i in enumerate(route)}
        for i in route:
            s = stops[i]
            if s['kind'] == 'pickup' and not (s['pair'] in where and where[s['pair']] > where[i]):
                return None, 'pickup %d: its delivery %d must come later on the same route' % (i, s['pair'])
            if s['kind'] == 'delivery' and not (s['pair'] in where and where[s['pair']] < where[i]):
                return None, 'delivery %d: its pickup %d must come earlier on the same route' % (i, s['pair'])
        load = sum(stops[i]['load'] for i in route if stops[i]['kind'] == 'drop')
        if load > city['capacity']: return None, 'route %d: drop-off goods exceed the capacity at the depot' % n
        t, pos, d = 0, city['depot'], 0
        for i in route:
            s = stops[i]
            t += dist(pos, s['xy']); d += dist(pos, s['xy']); pos = s['xy']
            start = max(t, s['window'][0])
            if start > s['window'][1]: return None, 'stop %d: service would start at %d, after its window closes at %d' % (i, start, s['window'][1])
            load += s['load'] if s['kind'] == 'pickup' else -s['load']
            if load > city['capacity']: return None, 'route %d: load %d exceeds the capacity after stop %d' % (n, load, i)
            t = start + s['service']
        t += dist(pos, city['depot']); d += dist(pos, city['depot'])
        if t > city['shift']: return None, 'route %d: back at the depot at %d, after the shift ends at %d' % (n, t, city['shift'])
        total += city['vehicle_cost'] + d
    if len(seen) != len(stops): return None, 'every stop must be visited exactly once'
    return total, None
import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

import json
def check(city, answer):
    if too_deep(answer): return None, 'answer nested deeper than %d' % MAX_DEPTH
    try: answer = json.loads(json.dumps(answer, allow_nan=False))  # the same JSON round trip as in the grader
    except (TypeError, ValueError, RecursionError): return None, 'not JSON data'
    try: return cost(city, answer)
    except Exception as exc: return None, 'checker error: ' + type(exc).__name__
if __name__ == '__main__':
    import importlib.util, sys, time
    path = sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py'
    spec = importlib.util.spec_from_file_location('candidate', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    scores = []
    for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
        started = time.monotonic()
        try: c, why = check(e['city'], module.solve(json.loads(json.dumps(e['city']))))
        except Exception as exc: c, why = None, 'error: ' + type(exc).__name__
        s = score(e['floor'], e['ref'], c); scores.append(s)
        print('example %d: %d stops, floor %d, ref %d, you %s, score %.3f, %.1fs%s' % (i, len(e['city']['stops']), e['floor'], e['ref'], c, s,
              time.monotonic() - started, '' if c else ' (' + why + ')'))
    print('mean score %.3f' % (sum(scores) / len(scores)))
