# O4 · Dispatch · medium

Plan van routes from one depot. Serve every stop on time and keep the total of van fees and driving distance as
LOW as possible.

## Score
For each hidden city:
- `floor` is the cost of the simple append answer, `floor.py`.
- `ref` is the cost of our reference planner.
- `you` is your cost.

The rules:
- An invalid answer scores -0.15. Invalid means any rule below is broken, `solve` raises, or your group runs out of time.
- A valid answer scores `log(floor/you) / log(floor/ref)`, never below -0.15. The floor scores 0, the reference scores
  1, and cheaper than the reference scores above 1. There is no maximum.
- The task score is the mean over 30 hidden cities. They are made the same way as `examples.json`, and they are
  minted only after your run ends.

## Input
`city` = `{"depot":[x,y], "capacity":Q, "vehicle_cost":F, "shift":H, "stops":[...]}`.

Each stop is `{"id", "xy":[x,y], "kind", "load", "window":[a,b], "service", "pair"}`, where `kind` is one of:
- `"drop"`: goods loaded at the depot and unloaded here. `pair` is null.
- `"pickup"`: goods loaded here and unloaded at its `"delivery"` stop, whose id is in `pair`.
- `"delivery"`: the end of a pickup's trip. Its `pair` is the pickup id.

Coordinates are 0..80. Each city has 32..40 drops and 8..12 pickup/delivery pairs. Q=20, F=80, H=500.
Every job (a single drop, or a pickup with its delivery) can be served alone by its own van.

## Output
`solve(city)` returns a list of routes. Each route is a non-empty list of stop ids, in visiting order. Every van starts
at the depot at time 0 and returns there after its last stop.

## Rules (`check.py` enforces exactly these)
1. Every stop is visited exactly once, on exactly one route.
2. A pickup and its delivery are on the same route, with the pickup first.
3. Load: a van leaves the depot carrying the drop-off goods of all its drop stops. A drop stop removes its load, a
   pickup adds its load, and a delivery removes it. The load must never exceed the capacity, at the depot or after any stop.
4. Time:
   - Driving between points takes their Manhattan distance |dx|+|dy|.
   - Service at a stop starts at max(arrival, a) and must start no later than b, so waiting is allowed and being late
     is not.
   - Service takes `service` time.
   - The van must be back at the depot no later than the shift end H.
5. Cost = F per route + the total distance driven by all vans, including the legs from and back to the depot.

## Interface
- `answers/solution.py` with `solve(city)`.
- Use the Python 3.12 standard library only, with no network, one CPU and 512 MB of memory.
- Hidden cities run in groups of 10, each group in one process with 100 seconds. A group that runs
  out of time makes all 10 of its cities invalid.
- Your answer passes through JSON on its way to the grader. `check.py` does the same round trip, and `solve` gets a
  copy of the city.

## Tools in this folder
- `check.py` is the exact checker and scorer. `python check.py` runs `answers/solution.py` on `examples.json`.
- `floor.py` makes the simple append answer: jobs by deadline, each added to the newest van if it fits.
- `examples.json` holds public cities, each with `floor`, `ref` and our reference routes `ref_answer`.
