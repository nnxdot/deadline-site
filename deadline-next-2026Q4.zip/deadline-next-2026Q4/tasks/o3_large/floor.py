def solve(truck):
    """Towers on a grid of side x side cells, each box lying on its largest face (upright boxes stand as given).
    Lanes run from the back wall (x = 0) toward the door; later stops fill the back lanes first, so no later-stop
    box is ever above or in front of an earlier-stop box. In each tower, later stops are lower."""
    W, D = truck['W'], truck['D']
    side = max(max(b['size']) for b in truck['boxes'])
    lanes, cols = max(1, W // side), max(1, D // side)
    order = sorted(truck['boxes'], key=lambda b: (-b['stop'], b['id']))
    per_lane = -(-len(order) // lanes)
    height = [[0] * cols for _ in range(lanes)]
    out = []
    for k, b in enumerate(order):
        lane = k // per_lane
        col = (k - lane * per_lane) % cols
        a, c, h = b['size']
        dims = (a, c, h) if b['upright'] else tuple(sorted(b['size'], reverse=True))
        out.append([b['id'], lane * side, col * side, height[lane][col], dims[0], dims[1], dims[2]])
        height[lane][col] += dims[2]
    return out
