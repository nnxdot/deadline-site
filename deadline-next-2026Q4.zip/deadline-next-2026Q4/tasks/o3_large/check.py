ZMAX = 1000
def _overlap(a0, a1, b0, b1): return min(a1, b1) - max(a0, b0)
def cost(truck, answer):
    """(height, None) if answer follows every rule, else (None, the first broken rule)."""
    W, D, boxes = truck['W'], truck['D'], {b['id']: b for b in truck['boxes']}
    if type(answer) is not list or len(answer) != len(boxes): return None, 'answer must be a list with one entry per box'
    placed, seen = [], set()
    for e in answer:
        if type(e) is not list or len(e) != 7 or any(type(v) is not int for v in e): return None, 'each entry is [id,x,y,z,dx,dy,dz] of 7 ints'
        i, x, y, z, dx, dy, dz = e
        if i not in boxes or i in seen: return None, 'unknown or repeated box id %r' % (i,)
        seen.add(i); b = boxes[i]
        if sorted((dx, dy, dz)) != sorted(b['size']): return None, 'box %d: dims must be a rotation of its size' % i
        if b['upright'] and dz != b['size'][2]: return None, 'box %d is upright: its height must stay %d' % (i, b['size'][2])
        if x < 0 or y < 0 or z < 0 or x + dx > W or y + dy > D or z + dz > ZMAX: return None, 'box %d is outside the truck' % i
        placed.append((i, x, y, z, dx, dy, dz, b['stop']))
    for a in range(len(placed)):
        i, x, y, z, dx, dy, dz, s = placed[a]
        if z > 0 and not any(q[3] + q[6] == z and _overlap(x, x + dx, q[1], q[1] + q[4]) > 0 and _overlap(y, y + dy, q[2], q[2] + q[5]) > 0
                             for q in placed if q[0] != i):
            return None, 'box %d floats: it must stand on the floor or on another box' % i
        for b in range(a + 1, len(placed)):
            j, X, Y, Z, DX, DY, DZ, S = placed[b]
            ox, oy, oz = _overlap(x, x + dx, X, X + DX), _overlap(y, y + dy, Y, Y + DY), _overlap(z, z + dz, Z, Z + DZ)
            if ox > 0 and oy > 0 and oz > 0: return None, 'boxes %d and %d overlap' % (i, j)
            for (p, P, sp, sP) in (((x, y, z, dx, dy, dz), (X, Y, Z, DX, DY, DZ), s, S), ((X, Y, Z, DX, DY, DZ), (x, y, z, dx, dy, dz), S, s)):
                # P blocks p if P is above p (with xy overlap) or in front of p toward the door (with yz overlap).
                if sP > sp and ((P[2] >= p[2] + p[5] and _overlap(p[0], p[0] + p[3], P[0], P[0] + P[3]) > 0 and _overlap(p[1], p[1] + p[4], P[1], P[1] + P[4]) > 0)
                                or (P[0] >= p[0] + p[3] and _overlap(p[1], p[1] + p[4], P[1], P[1] + P[4]) > 0 and _overlap(p[2], p[2] + p[5], P[2], P[2] + P[5]) > 0)):
                    return None, 'delivery order: a later-stop box blocks an earlier-stop box'
    return max(q[3] + q[6] for q in placed), None
import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

import json
def check(truck, answer):
    if too_deep(answer): return None, 'answer nested deeper than %d' % MAX_DEPTH
    try: answer = json.loads(json.dumps(answer, allow_nan=False))  # the same JSON round trip as in the grader
    except (TypeError, ValueError, RecursionError): return None, 'not JSON data'
    try: return cost(truck, answer)
    except Exception as exc: return None, 'checker error: ' + type(exc).__name__
if __name__ == '__main__':
    import importlib.util, sys, time
    path = sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py'
    spec = importlib.util.spec_from_file_location('candidate', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    scores = []
    for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
        started = time.monotonic()
        try: h, why = check(e['truck'], module.solve(json.loads(json.dumps(e['truck']))))
        except Exception as exc: h, why = None, 'error: ' + type(exc).__name__
        s = score(e['floor'], e['ref'], h); scores.append(s)
        print('example %d: %d boxes, floor %d, ref %d, you %s, score %.3f, %.1fs%s' % (i, len(e['truck']['boxes']), e['floor'], e['ref'], h, s,
              time.monotonic() - started, '' if h else ' (' + why + ')'))
    print('mean score %.3f' % (sum(scores) / len(scores)))
