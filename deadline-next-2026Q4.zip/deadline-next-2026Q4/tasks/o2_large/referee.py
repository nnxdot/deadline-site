"""Outpost referee: the exact rules the grader runs. Shipped unchanged in every O2 room as referee.py.
Python 3 standard library only. Bots see only view(state, player), a plain JSON-ready dict."""

DIRS = {'U': (-1, 0), 'D': (1, 0), 'L': (0, -1), 'R': (0, 1)}
# A new unit takes the first free cell next to its base in this order. Player 1's order is player 0's turned
# 180 degrees, so the point-symmetric start is exactly mirrored.
SPAWN_SIDES = ('URDL', 'DLUR')
BASE_HP = 50
START_BANK = 10
CARRY = 5                     # most crystals a worker can hold
STATS = {'w': {'hp': 6, 'atk': 1, 'cost': 5}, 's': {'hp': 10, 'atk': 3, 'cost': 8}}


def new_game(game_map):
    """game_map: {"grid": [rows of '.' and '#'], "crystals": [[r,c,amount]], "bases": [[r,c],[r,c]], "T": turns}."""
    s = {'turn': 0, 'T': game_map['T'], 'grid': list(game_map['grid']),
         'crystals': {(r, c): a for r, c, a in game_map['crystals']},
         'bases': [{'r': r, 'c': c, 'hp': BASE_HP} for r, c in game_map['bases']],
         'bank': [START_BANK, START_BANK], 'units': {}, 'next_id': 1, 'over': False, 'end_turn': None,
         'bad_turns': [0, 0]}
    for p in (0, 1):
        for _ in range(2): _spawn(s, p, 'w')
    return s


def _inside(s, r, c):
    return 0 <= r < len(s['grid']) and 0 <= c < len(s['grid'][0])


def passable(s, r, c):
    """Ground a unit may stand on: inside the map, '.', no crystal, no base (units are handled by the move rules)."""
    return (_inside(s, r, c) and s['grid'][r][c] == '.' and (r, c) not in s['crystals']
            and all((b['r'], b['c']) != (r, c) for b in s['bases']))


def _spawn(s, p, kind):
    b = s['bases'][p]
    taken = {(u['r'], u['c']) for u in s['units'].values()}
    for side in SPAWN_SIDES[p]:
        dr, dc = DIRS[side]
        r, c = b['r'] + dr, b['c'] + dc
        if passable(s, r, c) and (r, c) not in taken:
            uid = s['next_id']; s['next_id'] += 1
            s['units'][uid] = {'id': uid, 'owner': p, 'kind': kind, 'r': r, 'c': c, 'hp': STATS[kind]['hp'], 'carry': 0}
            return True
    return False


def check_orders(s, p, orders):
    """None if orders are well formed for player p, else the reason. A bad order object loses the whole turn."""
    if type(orders) is not dict or not set(orders) <= {'units', 'spawn'}: return 'orders must be an object with "units" and/or "spawn"'
    spawn = orders.get('spawn')
    if spawn not in (None, 'w', 's'): return 'spawn must be null, "w" or "s"'
    units = orders.get('units', {})
    if type(units) is not dict: return '"units" must be an object'
    for key, order in units.items():
        # Keys are unit ids written as plain decimal strings ("12", not "012"), at most 9 digits.
        if (type(key) is not str or not (key.isascii() and key.isdigit()) or len(key) > 9 or key != str(int(key))
                or int(key) not in s['units'] or s['units'][int(key)]['owner'] != p):
            return 'unit %r is not one of your living units' % (key,)
        if type(order) is not list or not order or type(order[0]) is not str or order[0] not in ('move', 'attack', 'harvest', 'stay'):
            return 'order for unit %s must be ["move"|"attack"|"harvest", dir] or ["stay"]' % key
        if order[0] == 'stay':
            if len(order) != 1: return 'order for unit %s: ["stay"] takes no direction' % key
        elif len(order) != 2 or type(order[1]) is not str or order[1] not in DIRS: return 'order for unit %s needs one direction U, D, L or R' % key
    return None


def step(s, orders):
    """Play one turn. orders = [orders of player 0, orders of player 1]; each already checked (bad ones replaced by {})."""
    s['turn'] += 1
    units = s['units']
    act = {}
    for p in (0, 1):
        for key, order in (orders[p].get('units') or {}).items(): act[int(key)] = order
    at = {(u['r'], u['c']): u for u in units.values()}
    # 1. Attacks: all damage is summed, then applied at once. A unit that attacks does nothing else.
    hurt, base_hurt = {}, [0, 0]
    for uid in sorted(act):
        order, u = act[uid], units[uid]
        if order[0] != 'attack': continue
        dr, dc = DIRS[order[1]]
        cell = (u['r'] + dr, u['c'] + dc)
        target, enemy = at.get(cell), 1 - u['owner']
        if target is not None and target['owner'] == enemy: hurt[target['id']] = hurt.get(target['id'], 0) + STATS[u['kind']]['atk']
        elif (s['bases'][enemy]['r'], s['bases'][enemy]['c']) == cell: base_hurt[enemy] += STATS[u['kind']]['atk']
    for uid, damage in hurt.items(): units[uid]['hp'] -= damage
    for p in (0, 1): s['bases'][p]['hp'] -= base_hurt[p]
    for uid in [i for i, u in units.items() if u['hp'] <= 0]: del units[uid]
    # 2. Harvest: a worker holding fewer than CARRY takes 1 crystal from the next cell. If more workers harvest one
    #    cell this turn than it has crystals left, none of them get any (the same for both players).
    pulls = {}
    for uid in sorted(act):
        if uid not in units or act[uid][0] != 'harvest': continue
        u = units[uid]
        if u['kind'] != 'w' or u['carry'] >= CARRY: continue
        dr, dc = DIRS[act[uid][1]]
        cell = (u['r'] + dr, u['c'] + dc)
        if s['crystals'].get(cell, 0) > 0: pulls.setdefault(cell, []).append(u)
    for cell, workers in pulls.items():
        if len(workers) > s['crystals'][cell]: continue
        for u in workers: u['carry'] += 1
        s['crystals'][cell] -= len(workers)
        if s['crystals'][cell] == 0: del s['crystals'][cell]
    # 3. Moves. A move fails if: the target is not passable; two or more units target the same cell; two units swap;
    #    or the target holds a unit that does not itself move away successfully (repeated until nothing changes).
    movers = {}
    for uid in sorted(act):
        if uid in units and act[uid][0] == 'move':
            u = units[uid]; dr, dc = DIRS[act[uid][1]]
            cell = (u['r'] + dr, u['c'] + dc)
            if passable(s, *cell): movers[uid] = cell
    claims = {}
    for cell in movers.values(): claims[cell] = claims.get(cell, 0) + 1
    movers = {uid: cell for uid, cell in movers.items() if claims[cell] == 1}
    at = {(u['r'], u['c']): uid for uid, u in units.items()}
    for a in list(movers):
        if a not in movers: continue  # already dropped as the other half of a swap
        b = at.get(movers[a])
        if b in movers and movers[b] == (units[a]['r'], units[a]['c']): movers.pop(a, None); movers.pop(b, None)
    changed = True
    while changed:
        changed = False
        for a in list(movers):
            b = at.get(movers[a])
            if b is not None and b not in movers: del movers[a]; changed = True
    for uid, (r, c) in movers.items(): units[uid]['r'], units[uid]['c'] = r, c
    # 4. Deposit: every worker next to its own base adds what it carries to the bank.
    for uid in sorted(units):
        u = units[uid]; b = s['bases'][u['owner']]
        if u['kind'] == 'w' and u['carry'] and abs(u['r'] - b['r']) + abs(u['c'] - b['c']) == 1:
            s['bank'][u['owner']] += u['carry']; u['carry'] = 0
    # 5. Spawn: player 0 first, then player 1. Paid only if a free cell exists.
    for p in (0, 1):
        kind = orders[p].get('spawn')
        if kind and s['bank'][p] >= STATS[kind]['cost'] and _spawn(s, p, kind): s['bank'][p] -= STATS[kind]['cost']
    # 6. End: a base at 0 HP or less falls; the game also ends after turn T.
    if any(b['hp'] <= 0 for b in s['bases']) or s['turn'] >= s['T']:
        s['over'], s['end_turn'] = True, s['turn']


def view(s, p):
    """What a bot sees before each turn (full information). "turn" is the number of the turn about to be played."""
    return {'turn': s['turn'] + 1, 'T': s['T'], 'me': p, 'grid': list(s['grid']),
            'crystals': [[r, c, a] for (r, c), a in sorted(s['crystals'].items())],
            'bases': [[b['r'], b['c'], b['hp']] for b in s['bases']], 'bank': list(s['bank']),
            'units': [[u['id'], u['owner'], u['kind'], u['r'], u['c'], u['hp'], u['carry']] for _, u in sorted(s['units'].items())]}


def cost(s, p):
    """Lower is better. A win costs the turn the enemy base fell; any other result costs more than T."""
    T, mine, theirs = s['T'], s['bases'][p]['hp'], s['bases'][1 - p]['hp']
    if theirs <= 0 < mine: return s['end_turn']
    enemy_left, own_lost = max(0, theirs) / BASE_HP, 1 - max(0, mine) / BASE_HP
    return T * (1 + enemy_left + own_lost) + (T - s['end_turn'] if mine <= 0 else 0)


def play(game_map, bots, log=None):
    """Run a full game between two in-process bots (callables view -> orders). Returns the final state.
    Each bot gets a JSON copy of its view and its orders make a JSON round trip, exactly as in the grader's sandbox.
    A bot that raises, or returns something that is not JSON data, loses that turn's orders."""
    import json
    s = new_game(game_map)
    while not s['over']:
        orders = []
        for p in (0, 1):
            try: o = json.loads(json.dumps(bots[p](json.loads(json.dumps(view(s, p)))), allow_nan=False))
            except Exception: o = None
            try: bad = o is None or check_orders(s, p, o)
            except Exception: bad = True
            if bad: s['bad_turns'][p] += 1; o = {}
            orders.append(o)
        if log is not None: log.append(orders)
        step(s, orders)
    return s
