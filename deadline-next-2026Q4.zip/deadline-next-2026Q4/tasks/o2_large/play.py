import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

"""python play.py [answers/solution.py]: plays your bot on every example in examples.json, in this process,
and prints the referee cost and the exact grader score for each. Timing here is only a rough guide."""
import importlib.util, json, sys, time
import referee, bots
path = sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py'
spec = importlib.util.spec_from_file_location('solution', path)
scores = []
for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)  # fresh module per match
    side, opponent = e['side'], bots.BOTS[e['opponent']]()
    started = time.monotonic()
    s = referee.play(e['map'], [module.act, opponent.act] if side == 0 else [opponent.act, module.act])
    you = referee.cost(s, side); sc = score(e['floor'], e['ref'], you); scores.append(sc)
    print('example %d vs %-9s side %d: floor %.0f, ref %.0f, you %.1f, score %.3f, base hp %s, bad turns %d, %.1fs'
          % (i, e['opponent'], side, e['floor'], e['ref'], you, sc, [b['hp'] for b in s['bases']], s['bad_turns'][side], time.monotonic() - started))
print('mean score %.3f' % (sum(scores) / len(scores)))
