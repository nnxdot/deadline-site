"""Outpost ladder bots. Shipped unchanged in every O2 room as bots.py. Each bot: Bot().act(view) -> orders.
idle is the floor (score 0). The reference (score 1) is, per match, the lowest cost any of the other five bots gets
in the same seat. All are deterministic. Python 3 standard library only."""
from collections import deque

DIRS = {'U': (-1, 0), 'D': (1, 0), 'L': (0, -1), 'R': (0, 1)}
ORDER = 'URDL'
MIRROR = {'U': 'D', 'D': 'U', 'L': 'R', 'R': 'L'}  # player 1 sees the board turned 180 degrees
CARRY, COST = 5, {'w': 5, 's': 8}
INF = float('inf')


class World:
    """One turn's view with the helpers every bot uses: passability, multi-source BFS and greedy steps."""
    def __init__(self, v):
        self.v, self.me, self.turn, self.T = v, v['me'], v['turn'], v['T']
        self.grid, self.H, self.W = v['grid'], len(v['grid']), len(v['grid'][0])
        self.crystals = {(r, c): a for r, c, a in v['crystals']}
        self.bases = [(b[0], b[1]) for b in v['bases']]
        self.units = [dict(zip(('id', 'owner', 'kind', 'r', 'c', 'hp', 'carry'), u)) for u in v['units']]
        # Full workers first: they leave dead ends before others try to enter them.
        self.mine = sorted((u for u in self.units if u['owner'] == self.me),
                           key=lambda u: (not (u['kind'] == 'w' and u['carry'] >= CARRY), u['id']))
        self.theirs = [u for u in self.units if u['owner'] != self.me]
        self.at = {(u['r'], u['c']): u for u in self.units}
        self.bank = v['bank'][self.me]
        # Player 1 uses the mirrored direction order, and ranks (not raw ids) break ties, so mirrored seats play alike.
        self.order = ORDER if self.me == 0 else ''.join(MIRROR[k] for k in ORDER)
        self.rank = {u['id']: i for i, u in enumerate(sorted((u for u in self.units if u['owner'] == self.me), key=lambda u: u['id']))}
        self.reserved, self.vacating, self.targets = set(), set(), {}
        self._dist = {}

    def passable(self, r, c):
        return 0 <= r < self.H and 0 <= c < self.W and self.grid[r][c] == '.' and (r, c) not in self.crystals and (r, c) not in self.bases

    def around(self, cells):
        out = set()
        for r, c in cells:
            for dr, dc in DIRS.values():
                if self.passable(r + dr, c + dc): out.add((r + dr, c + dc))
        return out

    def dist(self, key, goals):
        """Steps from every passable cell to the nearest goal cell, ignoring units. Cached per turn by key."""
        if key not in self._dist:
            d, q = {}, deque()
            for g in goals:
                if g not in d: d[g] = 0; q.append(g)
            while q:
                r, c = q.popleft()
                for dr, dc in DIRS.values():
                    n = (r + dr, c + dc)
                    if n not in d and self.passable(*n): d[n] = d[(r, c)] + 1; q.append(n)
            self._dist[key] = d
        return self._dist[key]

    def home(self): return self.dist('home', self.around([self.bases[self.me]]))
    def enemy_base(self): return self.dist('enemy-base', self.around([self.bases[1 - self.me]]))
    def crystal(self): return self.dist('crystal', self.around(self.crystals))

    def step(self, u, d):
        """One move under distance map d: closer if possible, else sideways (to break jams), else None.
        A unit may follow a friend that already got a move order this turn, but never swaps with it."""
        pos = (u['r'], u['c'])
        here = d.get(pos, INF)
        options = []
        for i, k in enumerate(self.order):
            dr, dc = DIRS[k]
            n = (pos[0] + dr, pos[1] + dc)
            if not self.passable(*n) or n in self.reserved: continue
            other = self.at.get(n)
            if other is not None and (n not in self.vacating or self.targets.get(other['id']) == pos): continue
            if d.get(n, INF) < INF: options.append((d[n], (i + self.turn + self.rank[u['id']]) % 4, k, n))
        better = [o for o in options if o[0] < here] or [o for o in options if o[0] == here]
        if not better and (self.turn + self.rank[u['id']]) % 3 == 0: better = options  # now and then step back to clear a jam
        if not better: return None
        _, _, k, n = min(better)
        self.reserved.add(n); self.vacating.add(pos); self.targets[u['id']] = n
        return ['move', k]

    def guard(self, u, ring=2):
        """Wait on the ring of cells `ring` steps from the cells next to home, so the base stays open for deposits."""
        home = self.home()
        if home.get((u['r'], u['c'])) == ring: return None
        return self.step(u, self.dist(('ring', ring), [c for c, k in home.items() if k == ring]))

    def near(self, a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def fight(self, u):
        """Attack something next to u: an enemy soldier first, then the enemy base, then an enemy worker (lowest HP)."""
        options = []
        eb = self.bases[1 - self.me]
        for i, k in enumerate(self.order):  # ties go by this side's direction order, so mirrored seats attack alike
            dr, dc = DIRS[k]
            n = (u['r'] + dr, u['c'] + dc)
            e = self.at.get(n)
            if e is not None and e['owner'] != self.me: options.append((0 if e['kind'] == 's' else 2, e['hp'], i, k))
            elif n == eb: options.append((1, 0, i, k))
        return ['attack', min(options)[3]] if options else None

    def work(self, u):
        """Harvest the next crystal, walk to the nearest one, or bring a full load home (deposit is automatic)."""
        pos = (u['r'], u['c'])
        if u['carry'] >= CARRY or (u['carry'] and not self.crystals):
            return None if self.home().get(pos) == 0 else self.step(u, self.home())
        for k in self.order:
            dr, dc = DIRS[k]
            if (pos[0] + dr, pos[1] + dc) in self.crystals: return ['harvest', k]
        return self.step(u, self.crystal())

    def toward_units(self, u, enemies):
        return self.step(u, self.dist(('enemies', tuple(sorted(e['id'] for e in enemies))), self.around([(e['r'], e['c']) for e in enemies])))

    def counts(self, units, kind): return sum(1 for x in units if x['kind'] == kind)


def pack(units, spawn):
    out = {'units': {str(i): o for i, o in units.items() if o}}
    if spawn: out['spawn'] = spawn
    return out


class Idle:
    """The floor: never orders anything."""
    def act(self, v): return {}


class Turtle:
    """Four workers, then soldiers that guard the base and chase anything that comes close."""
    def act(self, v):
        w = World(v); orders = {}
        workers = w.counts(w.mine, 'w')
        spawn = 'w' if workers < 4 and w.bank >= COST['w'] else ('s' if workers >= 4 and w.bank >= COST['s'] else None)
        home = w.bases[w.me]
        close = [e for e in w.theirs if w.near((e['r'], e['c']), home) <= 5]
        for u in w.mine:
            if u['kind'] == 'w': orders[u['id']] = w.work(u)
            else:
                orders[u['id']] = w.fight(u) or (w.toward_units(u, close) if close else
                                                 w.guard(u))
        return pack(orders, spawn)


class Rusher:
    """Two workers, then every crystal into soldiers that walk straight at the enemy base."""
    def act(self, v):
        w = World(v); orders = {}
        workers = w.counts(w.mine, 'w')
        spawn = 'w' if workers < 2 and w.bank >= COST['w'] else ('s' if w.bank >= COST['s'] else None)
        for u in w.mine:
            orders[u['id']] = w.work(u) if u['kind'] == 'w' else (w.fight(u) or w.step(u, w.enemy_base()))
        return pack(orders, spawn)


class Economist:
    """Eight workers, then soldiers that wait at home until six of them can attack together."""
    def __init__(self): self.launched = False
    def act(self, v):
        w = World(v); orders = {}
        workers, soldiers = w.counts(w.mine, 'w'), w.counts(w.mine, 's')
        spawn = 'w' if workers < 8 and w.bank >= COST['w'] else ('s' if workers >= 8 and w.bank >= COST['s'] else None)
        if soldiers >= 6: self.launched = True
        for u in w.mine:
            if u['kind'] == 'w': orders[u['id']] = w.work(u)
            elif self.launched: orders[u['id']] = w.fight(u) or w.step(u, w.enemy_base())
            else: orders[u['id']] = w.fight(u) or w.guard(u)
        return pack(orders, spawn)


class Balanced:
    """Five workers; the two oldest soldiers guard home, the rest attack in a group of four or more."""
    def __init__(self): self.launched = False
    def act(self, v):
        w = World(v); orders = {}
        workers = w.counts(w.mine, 'w')
        spawn = 'w' if workers < 5 and w.bank >= COST['w'] else ('s' if workers >= 5 and w.bank >= COST['s'] else None)
        soldiers = sorted((u for u in w.mine if u['kind'] == 's'), key=lambda u: u['id'])
        guards, attackers = soldiers[:2], soldiers[2:]
        if len(attackers) >= 4: self.launched = True
        home = w.bases[w.me]
        close = [e for e in w.theirs if w.near((e['r'], e['c']), home) <= 5]
        for u in w.mine:
            if u['kind'] == 'w': orders[u['id']] = w.work(u)
        for u in guards:
            orders[u['id']] = w.fight(u) or (w.toward_units(u, close) if close else
                                             w.guard(u))
        for u in attackers:
            if not self.launched: orders[u['id']] = w.fight(u) or w.guard(u, 3)
            else:
                near = [e for e in w.theirs if w.near((e['r'], e['c']), (u['r'], u['c'])) <= 4]
                orders[u['id']] = w.fight(u) or (w.toward_units(u, near) if near else w.step(u, w.enemy_base()))
        return pack(orders, spawn)


class Marshal:
    """An all-rounder. A small economy sized to the map, then a steady stream of soldiers. It attacks in a group once
    it has four soldiers and at least as many as the enemy (or late in the game); it calls nearby soldiers home when
    the base is threatened, focuses soldiers before workers, and pulls threatened workers home."""
    def __init__(self): self.launched = False
    def act(self, v):
        w = World(v); orders = {}
        workers = w.counts(w.mine, 'w')
        mine_s, their_s = w.counts(w.mine, 's'), w.counts(w.theirs, 's')
        target = 3 + (1 if w.H >= 24 else 0) + (1 if w.H >= 32 else 0)
        home = w.bases[w.me]
        threats = [e for e in w.theirs if e['kind'] == 's' and w.near((e['r'], e['c']), home) <= 7]
        if len(threats) >= mine_s and w.bank >= COST['s']: spawn = 's'
        elif workers < target and w.bank >= COST['w']: spawn = 'w'
        elif workers >= target and w.bank >= COST['s']: spawn = 's'
        else: spawn = None
        if mine_s == 0: self.launched = False
        if (mine_s >= 4 and mine_s >= their_s) or (w.turn > w.T * 0.5 and mine_s > their_s): self.launched = True
        for u in w.mine:
            pos = (u['r'], u['c'])
            if u['kind'] == 'w':
                danger = any(e['kind'] == 's' and w.near((e['r'], e['c']), pos) <= 2 for e in w.theirs)
                orders[u['id']] = (w.step(u, w.home()) if danger and w.home().get(pos, INF) > 0 else None) or w.work(u)
                continue
            hit = w.fight(u)
            close_to_home = w.near(pos, home) <= 9
            if hit: orders[u['id']] = hit
            elif threats and (not self.launched or close_to_home or len(threats) >= 2): orders[u['id']] = w.toward_units(u, threats)
            elif self.launched:
                near = [e for e in w.theirs if w.near((e['r'], e['c']), pos) <= 4]
                orders[u['id']] = w.toward_units(u, near) if near else w.step(u, w.enemy_base())
            else: orders[u['id']] = w.guard(u)
        return pack(orders, spawn)


BOTS = {'idle': Idle, 'turtle': Turtle, 'rusher': Rusher, 'economist': Economist, 'balanced': Balanced, 'marshal': Marshal}
OPPONENTS = ('turtle', 'rusher', 'economist', 'balanced', 'marshal')
