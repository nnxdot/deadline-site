# O3 · Truck loading · small

Load every box into a truck so the load is as LOW as possible, while following the gravity, rotation and
delivery-order rules.

## Score
For each hidden truck:
- `floor` is the height of the simple lane-and-tower answer, `floor.py`.
- `ref` is the height of our reference packer.
- `you` is your height: the top of the highest box.

The rules:
- An invalid answer scores -0.15. Invalid means any rule below is broken, `solve` raises, or your group runs out of time.
- A valid answer scores `log(floor/you) / log(floor/ref)`, never below -0.15. The floor scores 0, the reference scores
  1, and lower than the reference scores above 1. There is no maximum.
- The task score is the mean over 30 hidden trucks. They are made the same way as `examples.json`, and they are
  minted only after your run ends.

## Input
`truck` = `{"W":10,"D":8,"boxes":[{"id":i,"size":[a,b,c],"upright":bool,"stop":k}, ...]}`.
- The truck floor spans 0<=x<W and 0<=y<D, and z goes up with no height limit except z <= 1000.
- The DOOR is the x = W side.
- Each truck has 18..24 boxes. Every side is 1..5. Stops are 1..3.
- Stop 1 is unloaded first, through the door.

## Output
`solve(truck)` returns a list with exactly one entry per box: `[id, x, y, z, dx, dy, dz]`, all ints.
- The box fills x..x+dx, y..y+dy and z..z+dz.
- `(dx, dy, dz)` must be a rotation (any order) of `size`.
- An `upright` box must keep `dz = size[2]`. Only its footprint may turn.

## Rules (`check.py` enforces exactly these)
1. Inside: 0 <= x, x+dx <= W, 0 <= y, y+dy <= D, 0 <= z, z+dz <= 1000.
2. No two boxes overlap with positive volume. Touching faces is fine.
3. No floating box: a box with z > 0 must rest on at least one box whose top is exactly at z and whose footprint
   overlaps its footprint with positive area.
4. Delivery order: box P BLOCKS box Q if either:
   - P is above Q: P's z >= Q's top, and their footprints overlap with positive area; or
   - P is in front of Q, toward the door: P's x >= Q's x+dx, and their y-z faces overlap with positive area.

   A box for a LATER stop must never block a box for an EARLIER stop. Boxes for the same stop may block each other.

## Interface
- `answers/solution.py` with `solve(truck)`.
- Use the Python 3.12 standard library only, with no network, one CPU and 512 MB of memory.
- Hidden trucks run in groups of 10, each group in one process with 60 seconds. A group that runs
  out of time makes all 10 of its trucks invalid.
- Your answer passes through JSON on its way to the grader. `check.py` does the same round trip, and `solve` gets a
  copy of the truck.

## Tools in this folder
- `check.py` is the exact checker and scorer. `python check.py` runs `answers/solution.py` on `examples.json`.
- `floor.py` makes the simple lane-and-tower answer.
- `examples.json` holds public trucks, each with `floor`, `ref` and our reference packing `ref_answer`.
