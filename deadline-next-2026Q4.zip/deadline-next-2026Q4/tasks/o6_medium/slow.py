def solve(task):
    """Prefix matches under edits. task: {"text": str, "ops": [...]}; op ["set", i, ch] replaces character i,
    op ["lcp", i, j] reports the length of the longest common prefix of text[i:] and text[j:]."""
    s = list(task['text'])
    out = []
    for op in task['ops']:
        if op[0] == 'set':
            s[op[1]] = op[2]
        else:
            i, j, n = op[1], op[2], 0
            while i + n < len(s) and j + n < len(s) and s[i + n] == s[j + n]:
                n += 1
            out.append(n)
    return out
