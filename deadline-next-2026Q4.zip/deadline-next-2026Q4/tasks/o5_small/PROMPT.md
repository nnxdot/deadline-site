# O5 · Factory scheduling · small

Schedule every step of every job on the factory's machines. Make the weighted finish times and the lateness penalty as
LOW as possible.

## Score
For each hidden factory:
- `floor` is the cost of the simple append answer, `floor.py`.
- `ref` is the cost of our reference scheduler.
- `you` is your cost.

The rules:
- An invalid answer scores -0.15. Invalid means any rule below is broken, `solve` raises, or your group runs out of time.
- A valid answer scores `log(floor/you) / log(floor/ref)`, never below -0.15. The floor scores 0, the reference scores
  1, and cheaper than the reference scores above 1. There is no maximum.
- The task score is the mean over 30 hidden factories. They are made the same way as `examples.json`, and they are
  minted only after your run ends.

## Input
`shop` = `{"machines":M, "setup":[[...]], "maintenance":[[[a,b],...] per machine], "jobs":[...]}`.
- Each job is `{"release":r, "due":d, "weight":w, "steps":[{"family":f, "time":{"<machine>": duration, ...}}, ...]}`.
- A step may run only on the machines listed in its `time`, which also gives the duration on each one.
- The keys of `time` are machine numbers written as strings.
- Each factory has 7..9 jobs of 3..5 steps, 4 machines and 3 product families. Setup times are 0..8.

## Output
`solve(shop)` returns a list with one entry per step: `[job, step, machine, start]`, all ints.
- `job` and `step` are 0-based indexes.
- The step runs during [start, start + duration).

## Rules (`check.py` enforces exactly these)
1. Every step of every job is scheduled exactly once, on an allowed machine, with 0 <= start < 100000.
2. A job's first step starts no earlier than its release. Each later step starts no earlier than the end of the step
   before it.
3. On each machine, in order of start time: a step starts no earlier than the end of the machine's previous step plus
   `setup[previous family][this family]`. The machine's first step needs no setup.
4. A step may not overlap any maintenance window [a, b) of its machine. Setup time may overlap maintenance.
5. Cost = sum over jobs of `weight * C + 5 * weight * max(0, C - due)`, where C is the end of the job's last step.

## Interface
- `answers/solution.py` with `solve(shop)`.
- Use the Python 3.12 standard library only, with no network, one CPU and 512 MB of memory.
- Hidden factories run in groups of 10, each group in one process with 60 seconds. A group that runs
  out of time makes all 10 of its factories invalid.
- Your answer passes through JSON on its way to the grader. `check.py` does the same round trip, and `solve` gets a
  copy of the factory.

## Tools in this folder
- `check.py` is the exact checker and scorer. `python check.py` runs `answers/solution.py` on `examples.json`.
- `floor.py` makes the simple append answer: each step on its fastest-finishing machine, appended.
- `examples.json` holds public factories, each with `floor`, `ref` and our reference schedule `ref_answer`.
