def solve(shop):
    """Job by job, step by step: each step goes on the allowed machine where it would finish first, after that
    machine's last step (plus setup) and after the job's previous step, skipping maintenance windows."""
    free, last, out = {}, {}, []
    for j, job in enumerate(shop['jobs']):
        ready = job['release']
        for k, step in enumerate(job['steps']):
            best = None
            for ms, dur in step['time'].items():
                m = int(ms)
                start = max(ready, free.get(m, 0) + (shop['setup'][last[m]][step['family']] if m in last else 0))
                moved = True
                while moved:
                    moved = False
                    for a, b in shop['maintenance'][m]:
                        if start < b and a < start + dur: start = b; moved = True
                if best is None or (start + dur, m) < (best[0], best[1]): best = (start + dur, m, start)
            end, m, start = best
            out.append([j, k, m, start])
            free[m], last[m], ready = end, step['family'], end
    return out
