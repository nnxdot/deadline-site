TARDY, HORIZON = 5, 100000
def cost(shop, answer):
    """(cost, None) if the schedule follows every rule, else (None, the first broken rule)."""
    jobs, M = shop['jobs'], shop['machines']
    if type(answer) is not list: return None, 'answer must be a list of [job, step, machine, start]'
    want = {(j, k) for j, job in enumerate(jobs) for k in range(len(job['steps']))}
    at, runs = {}, {m: [] for m in range(M)}
    for e in answer:
        if type(e) is not list or len(e) != 4 or any(type(v) is not int for v in e): return None, 'each entry is [job, step, machine, start], 4 ints'
        j, k, m, start = e
        if (j, k) not in want or (j, k) in at: return None, 'unknown or repeated step %r' % ([j, k],)
        step = jobs[j]['steps'][k]
        if str(m) not in step['time']: return None, 'job %d step %d cannot run on machine %r' % (j, k, m)
        if not 0 <= start < HORIZON: return None, 'job %d step %d: start must be in 0..%d' % (j, k, HORIZON - 1)
        end = start + step['time'][str(m)]
        at[(j, k)] = (start, end); runs[m].append((start, end, step['family'], j, k))
    if len(at) != len(want): return None, 'every step of every job must be scheduled exactly once'
    for j, job in enumerate(jobs):
        ready = job['release']
        for k in range(len(job['steps'])):
            start, end = at[(j, k)]
            if start < ready: return None, 'job %d step %d starts before %s' % (j, k, 'its release' if k == 0 else 'its previous step ends')
            ready = end
    for m in range(M):
        last_end, last_family = None, None
        for start, end, family, j, k in sorted(runs[m]):
            if last_end is not None and start < last_end + shop['setup'][last_family][family]:
                return None, 'machine %d: job %d step %d starts before the previous step ends plus the setup time' % (m, j, k)
            for a, b in shop['maintenance'][m]:
                if start < b and a < end: return None, 'machine %d: job %d step %d overlaps maintenance [%d, %d)' % (m, j, k, a, b)
            last_end, last_family = end, family
    total = 0
    for j, job in enumerate(jobs):
        done = at[(j, len(job['steps']) - 1)][1]
        total += job['weight'] * done + TARDY * job['weight'] * max(0, done - job['due'])
    return total, None
import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

import json
def check(shop, answer):
    if too_deep(answer): return None, 'answer nested deeper than %d' % MAX_DEPTH
    try: answer = json.loads(json.dumps(answer, allow_nan=False))  # the same JSON round trip as in the grader
    except (TypeError, ValueError, RecursionError): return None, 'not JSON data'
    try: return cost(shop, answer)
    except Exception as exc: return None, 'checker error: ' + type(exc).__name__
if __name__ == '__main__':
    import importlib.util, sys, time
    path = sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py'
    spec = importlib.util.spec_from_file_location('candidate', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    scores = []
    for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
        started = time.monotonic()
        try: c, why = check(e['shop'], module.solve(json.loads(json.dumps(e['shop']))))
        except Exception as exc: c, why = None, 'error: ' + type(exc).__name__
        s = score(e['floor'], e['ref'], c); scores.append(s)
        print('example %d: %d jobs, floor %d, ref %d, you %s, score %.3f, %.1fs%s' % (i, len(e['shop']['jobs']), e['floor'], e['ref'], c, s,
              time.monotonic() - started, '' if c else ' (' + why + ')'))
    print('mean score %.3f' % (sum(scores) / len(scores)))
