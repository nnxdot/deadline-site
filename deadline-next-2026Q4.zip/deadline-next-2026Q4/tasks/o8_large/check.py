import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

"""python check.py: runs answers/solution.js on each example with node, renders it in a local Chrome/Edge (if found)
using measure_next.cjs, applies the grader's rules (validate.py) and prints sizes and estimated scores."""
import json, os, shutil, subprocess, sys, tempfile
from validate import validate
browsers = [r'C:\Program Files\Google\Chrome\Application\chrome.exe', r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
            '/usr/bin/chromium', '/usr/bin/google-chrome', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']
browser = next((b for b in browsers if os.path.exists(b)), None)
examples = json.load(open('examples.json', encoding='utf-8'))
run = "const m=require(process.argv[1]);const p=JSON.parse(require('fs').readFileSync(0,'utf8'));process.stdout.write(JSON.stringify(p.map(x=>m.solve(x))))"
htmls = json.loads(subprocess.run(['node', '-e', run, os.path.abspath('answers/solution.js')], input=json.dumps([e['page'] for e in examples]),
                                  capture_output=True, text=True, encoding='utf-8', check=True).stdout)
if not browser: print('no local Chrome/Edge found: solve ran, but cannot measure here'); sys.exit()
jobs = [{'html': h, 'width': e['page']['width'], 'height': 800} for h, e in zip(htmls, examples)]
raw = json.loads(subprocess.run(['node', 'measure_next.cjs'], input=json.dumps({'browser': browser, 'jobs': jobs}),
                                capture_output=True, text=True, encoding='utf-8', check=True).stdout)
scores = []
for i, (e, m) in enumerate(zip(examples, raw)):
    cost, why = validate(e['page'], m)
    s = score(e['floor'], e['ref'], cost); scores.append(s)
    print('example %d: floor %.0f, ref %.0f, you %s, estimated score %.3f%s' % (i, e['floor'], e['ref'], cost, s, '' if cost else ' (' + why + ')'))
print('mean estimated score %.3f' % (sum(scores) / len(scores)))
