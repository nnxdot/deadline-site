// DEADLINE Next layout measurer (O8). Same isolation as deadline4/measure/measure.cjs: candidate HTML never runs
// scripts, every network request fails, Chromium is driven over --remote-debugging-pipe. It is mounted read-only into
// the deadline4-chromium image at run time. Reads {"browser", "jobs":[{"html","width","height"}]}; writes one JSON array.
'use strict';
const {spawn} = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');

const MAX_SHOT = 16000;  // tallest page whose text can be checked in pixels

// Runs in an isolated world after the page has loaded. For every [data-dl] block: the box, the text the reader sees
// (innerText), the font and spacing settings, whether content overflows the box, whether any ancestor scales or
// transforms it, its tag and its ancestors' tags, and simple paint settings. For text it also returns the rectangles of
// the rendered lines (one per line fragment) and the natural width of the same text set in the standard font inside a
// closed shadow root, where no page style can reach it. Also counts @font-face fonts (web fonts are not allowed) and
// lists every selector, imported stylesheets included, that uses ::first-line or ::first-letter.
const MEASURE = `(() => {
  const norm = s => s.replace(/\\s+/g, ' ').trim();
  const de = document.documentElement;
  const out = {doc: {width: de.scrollWidth, height: de.scrollHeight}, fonts: document.fonts ? document.fonts.size : 0,
               blocks: {}, duplicates: [], pseudo: []};
  const seen = new Set();
  const walk = rules => { for (const r of rules) {
    if (r.selectorText && /first-(line|letter)/i.test(r.selectorText)) out.pseudo.push(r.selectorText.slice(0, 80));
    try { if (r.styleSheet && !seen.has(r.styleSheet)) { seen.add(r.styleSheet); walk(r.styleSheet.cssRules); } } catch (e) { out.pseudo.push('unreadable imported stylesheet'); }
    try { if (r.cssRules) walk(r.cssRules); } catch (e) {}
  } };
  for (const sheet of document.styleSheets) { try { seen.add(sheet); walk(sheet.cssRules); } catch (e) { out.pseudo.push('unreadable stylesheet'); } }
  const flat = el => {
    for (let p = el; p && p.nodeType === 1; p = p.parentElement) {
      const c = getComputedStyle(p);
      if (c.transform !== 'none' || (c.zoom && c.zoom !== '1') || (c.scale && c.scale !== 'none') ||
          (c.rotate && c.rotate !== 'none') || (c.translate && c.translate !== 'none') || c.display === 'none') return false;
    }
    return true;
  };
  const clear = v => /^transparent$|rgba\\([^)]*,\\s*0(\\.0+)?\\)$/.test(String(v).trim());
  const ink = el => {
    const r = el.getBoundingClientRect();
    for (let p = el; p && p.nodeType === 1; p = p.parentElement) {
      const c = getComputedStyle(p);
      if (c.opacity !== '1' || c.filter !== 'none' || c.clipPath !== 'none' || (c.maskImage || c.webkitMaskImage || 'none') !== 'none' ||
          (c.clip && c.clip !== 'auto') || c.contentVisibility !== 'visible' || c.visibility !== 'visible') return false;
      if (p !== el && p !== de && p !== document.body && (c.overflowX !== 'visible' || c.overflowY !== 'visible')) {
        const q = p.getBoundingClientRect();
        if (r.left < q.left - 0.5 || r.top < q.top - 0.5 || r.right > q.right + 0.5 || r.bottom > q.bottom + 0.5) return false;
      }
    }
    const c = getComputedStyle(el);
    return !clear(c.color) && !clear(c.webkitTextFillColor || c.color);
  };
  const tags = el => { const t = []; for (let p = el.parentElement; p; p = p.parentElement) t.push(p.tagName); return t; };
  const lines = el => {
    const range = document.createRange(); range.selectNodeContents(el);
    return [...range.getClientRects()].filter(q => q.width > 0 && q.height > 0)
      .map(q => [q.left + scrollX, q.top + scrollY, q.width, q.height].map(v => Math.round(v * 100) / 100));
  };
  // The standard font, out of reach of every page style: a closed shadow root under a host whose inline style resets all.
  const host = document.createElement('div');
  host.setAttribute('style', 'all:initial !important;position:absolute !important;left:0 !important;top:0 !important;' +
    'width:0 !important;height:0 !important;overflow:hidden !important;visibility:hidden !important');
  const shadow = host.attachShadow({mode: 'closed'});
  shadow.innerHTML = '<style>:host{all:initial}span{all:initial;font:16px/24px "DejaVu Sans";white-space:pre}</style><span></span>';
  const probe = shadow.querySelector('span');
  (document.body || de).appendChild(host);
  const natural = s => { probe.textContent = s; return probe.getBoundingClientRect().width; };
  probe.textContent = 'x';
  out.canon = {h: probe.getBoundingClientRect().height, space: natural('a a') - natural('aa')};
  for (const el of document.querySelectorAll('[data-dl]')) {
    const id = el.getAttribute('data-dl');
    if (id in out.blocks) { out.duplicates.push(id); continue; }
    const c = getComputedStyle(el), r = el.getBoundingClientRect();
    const text = norm(el.innerText || '');
    out.blocks[id] = {x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height, children: el.children.length,
      text, flat: flat(el), visible: c.visibility === 'visible', ink: ink(el),
      tag: el.tagName, parents: tags(el), lines: lines(el), natural: Math.round(natural(text) * 100) / 100,
      type: [c.fontSizeAdjust, c.fontKerning, c.fontFeatureSettings, c.fontVariationSettings, c.wordBreak, c.overflowWrap,
             c.hyphens || c.webkitHyphens, c.lineBreak, c.textRendering, c.direction, c.unicodeBidi],
      overflow: el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1,
      font: [c.fontSize, c.lineHeight, c.fontFamily, c.fontWeight, c.fontStyle, c.fontStretch, c.letterSpacing,
             c.wordSpacing, c.textIndent, c.textTransform, c.writingMode, c.fontVariant]};
  }
  host.remove();
  return out;
})()`;

// Hides every block (visibility, from the isolated world, as an important inline declaration) for the second shot.
const HIDE = `(() => {
  let ok = true;
  for (const el of document.querySelectorAll('[data-dl]')) {
    el.style.setProperty('visibility', 'hidden', 'important');
    if (getComputedStyle(el).visibility !== 'hidden') ok = false;
  }
  return ok;
})()`;

// Minimal PNG decoder for Chrome screenshots: 8-bit RGB or RGBA, not interlaced. Returns {width, height, channels, data}.
function decodePng(buf) {
  let pos = 8, width = 0, height = 0, type = 0;
  const idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos), kind = buf.toString('latin1', pos + 4, pos + 8), body = buf.subarray(pos + 8, pos + 8 + len);
    if (kind === 'IHDR') {
      width = body.readUInt32BE(0); height = body.readUInt32BE(4); type = body[9];
      if (body[8] !== 8 || (type !== 2 && type !== 6) || body[12] !== 0) throw new Error('unsupported png');
    } else if (kind === 'IDAT') idat.push(body);
    else if (kind === 'IEND') break;
    pos += 12 + len;
  }
  const channels = type === 6 ? 4 : 3, stride = width * channels;
  const raw = zlib.inflateSync(Buffer.concat(idat)), data = Buffer.alloc(stride * height);
  for (let y = 0; y < height; y++) {
    const filter = raw[y * (stride + 1)], src = y * (stride + 1) + 1, dst = y * stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= channels ? data[dst + x - channels] : 0, b = y ? data[dst - stride + x] : 0;
      const c = x >= channels && y ? data[dst - stride + x - channels] : 0;
      let v = raw[src + x];
      if (filter === 1) v += a; else if (filter === 2) v += b; else if (filter === 3) v += (a + b) >> 1;
      else if (filter === 4) { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      data[dst + x] = v & 255;
    }
  }
  return {width, height, channels, data};
}

// Share of pixels in a rectangle whose color changes clearly (some channel by 64 or more) between the two shots.
function inkShare(a, b, [x, y, w, h]) {
  const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
  const x1 = Math.min(a.width, Math.ceil(x + w)), y1 = Math.min(a.height, Math.ceil(y + h));
  if (x1 <= x0 || y1 <= y0) return 0;
  let hit = 0;
  for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
    const i = (yy * a.width + xx) * a.channels;
    if (Math.abs(a.data[i] - b.data[i]) >= 64 || Math.abs(a.data[i + 1] - b.data[i + 1]) >= 64 || Math.abs(a.data[i + 2] - b.data[i + 2]) >= 64) hit++;
  }
  return Math.round(1000 * hit / ((x1 - x0) * (y1 - y0))) / 1000;
}

function launch(browser) {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'dl-next-'));
  const args = ['--headless=new', '--remote-debugging-pipe', '--no-first-run', '--no-default-browser-check',
    '--disable-gpu', '--disable-extensions', '--disable-background-networking', '--disable-sync',
    '--disable-component-update', '--disable-default-apps', '--mute-audio', '--hide-scrollbars',
    '--force-device-scale-factor=1', '--font-render-hinting=none', '--disable-dev-shm-usage',
    '--blink-settings=scriptEnabled=false', '--user-data-dir=' + profile, 'about:blank'];
  if (process.env.DEADLINE_MEASURER_NO_SANDBOX === '1') args.unshift('--no-sandbox');
  const child = spawn(browser, args, {stdio: ['ignore', 'ignore', 'pipe', 'pipe', 'pipe']});
  child.stderr.resume();
  let id = 0, buffer = '';
  const waiting = new Map(), listeners = [];
  child.stdio[4].on('data', chunk => {
    buffer += chunk.toString('utf8');
    let end;
    while ((end = buffer.indexOf('\0')) >= 0) {
      const message = JSON.parse(buffer.slice(0, end));
      buffer = buffer.slice(end + 1);
      if (message.id && waiting.has(message.id)) {
        const {resolve, reject} = waiting.get(message.id);
        waiting.delete(message.id);
        message.error ? reject(new Error(message.error.message)) : resolve(message.result);
      } else for (const fn of listeners) fn(message);
    }
  });
  const send = (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const message = {id: ++id, method, params};
    if (sessionId) message.sessionId = sessionId;
    waiting.set(message.id, {resolve, reject});
    child.stdio[3].write(JSON.stringify(message) + '\0');
  });
  const close = () => { try { child.kill(); } catch (e) {} try { fs.rmSync(profile, {recursive: true, force: true}); } catch (e) {} };
  return {send, listeners, close};
}

async function main() {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  const b = launch(input.browser);
  const results = [];
  try {
    const {targetId} = await b.send('Target.createTarget', {url: 'about:blank'});
    const {sessionId} = await b.send('Target.attachToTarget', {targetId, flatten: true});
    const s = (method, params) => b.send(method, params, sessionId);
    b.listeners.push(m => {
      if (m.method === 'Fetch.requestPaused' && m.sessionId === sessionId)
        s('Fetch.failRequest', {requestId: m.params.requestId, errorReason: 'BlockedByClient'}).catch(() => {});
    });
    await s('Page.enable');
    await s('Fetch.enable', {patterns: [{urlPattern: '*'}]});
    await s('Emulation.setScriptExecutionDisabled', {value: true});
    for (const job of input.jobs) {
      try {
        await s('Emulation.setDeviceMetricsOverride', {width: job.width, height: job.height, deviceScaleFactor: 1, mobile: false});
        await s('Page.navigate', {url: 'about:blank'});
        const frame = (await s('Page.getFrameTree')).frameTree.frame.id;
        await s('Page.setDocumentContent', {frameId: frame, html: job.html});
        const {executionContextId} = await s('Page.createIsolatedWorld', {frameId: frame, worldName: 'deadline-next'});
        const value = await s('Runtime.evaluate', {expression: MEASURE, contextId: executionContextId, returnByValue: true});
        if (value.exceptionDetails) throw new Error('measure failed');
        const out = value.result.value;
        // Ink check: one shot as rendered, one with every block hidden. Each text line must change clearly.
        const height = Math.min(MAX_SHOT, Math.ceil(out.doc.height));
        const shot = async () => decodePng(Buffer.from((await s('Page.captureScreenshot', {format: 'png', captureBeyondViewport: true,
          clip: {x: 0, y: 0, width: job.width, height, scale: 1}})).data, 'base64'));
        const shown = await shot();
        const hide = await s('Runtime.evaluate', {expression: HIDE, contextId: executionContextId, returnByValue: true});
        out.hidden_ok = !hide.exceptionDetails && hide.result.value === true;
        const hidden = await shot();
        out.shot_height = height;
        for (const block of Object.values(out.blocks))
          block.ink_lines = shown.width === hidden.width && shown.height === hidden.height
            ? block.lines.map(r => (r[1] + r[3] <= height ? inkShare(shown, hidden, r) : null)) : null;
        results.push(out);
      } catch (e) {
        results.push({error: 'render failed'});
      }
    }
  } finally {
    b.close();
  }
  process.stdout.write(JSON.stringify(results));
}

main().catch(e => { process.stderr.write(String(e && e.stack || e)); process.exit(1); });
