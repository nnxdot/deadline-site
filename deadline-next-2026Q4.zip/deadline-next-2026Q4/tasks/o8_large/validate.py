FONT = ['16px', '24px', None, '400', 'normal', '100%', 'normal', '0px', '0px', 'none', 'horizontal-tb', 'normal']
TYPE = [('none',), ('auto',), ('normal',), ('normal',), ('normal',), ('normal',), ('manual',), ('auto',), ('auto',), ('ltr',), ('normal', 'isolate')]
INK = 0.05
TEXT_TAGS = set(['ARTICLE', 'ASIDE', 'BLOCKQUOTE', 'DIV', 'FIGCAPTION', 'FOOTER', 'HEADER', 'LI', 'MAIN', 'P', 'SECTION', 'SPAN'])
PARENT_TAGS = set(['ARTICLE', 'ASIDE', 'BLOCKQUOTE', 'BODY', 'DIV', 'FIGCAPTION', 'FIGURE', 'FOOTER', 'HEADER', 'HTML', 'LI', 'MAIN', 'NAV', 'OL', 'P', 'SECTION', 'SPAN', 'TABLE', 'TBODY', 'TD', 'TFOOT', 'TH', 'THEAD', 'TR', 'UL'])

def validate(page, raw):
    """(cost, None) if the measured page follows every rule, else (None, the first broken rule)."""
    if not isinstance(raw, dict) or 'error' in raw: return None, 'render failed'
    W = page['width']
    if raw.get('fonts'): return None, 'web fonts (@font-face) are not allowed'
    if raw.get('duplicates'): return None, 'a data-dl id is used twice: ' + ', '.join(sorted(set(raw['duplicates'])))
    if raw.get('pseudo'): return None, '::first-line and ::first-letter are not allowed: ' + raw['pseudo'][0]
    if not raw.get('hidden_ok'): return None, 'blocks must be hideable for the ink check (no rules that keep them visible)'
    want = {b['id']: b for b in page['blocks']}
    got = raw['blocks']
    if set(got) != set(want): return None, 'the data-dl ids must be exactly the block ids'
    if raw['doc']['width'] > W + 0.5: return None, 'the page is wider than %d px' % W
    boxes = []
    for i, b in want.items():
        m = got[i]
        if not m['flat']: return None, '%s: no transform, scale, rotate, translate or zoom on a block or its ancestors' % i
        if not m['visible'] or m['w'] <= 0 or m['h'] <= 0: return None, '%s is not visible' % i
        if m['x'] < -0.5 or m['y'] < -0.5 or m['x'] + m['w'] > W + 0.5: return None, '%s is outside the page' % i
        if not set(m['parents']) <= PARENT_TAGS:
            return None, '%s: blocks sit only inside plain elements (%s)' % (i, ', '.join(sorted(PARENT_TAGS)).lower())
        if b['kind'] == 'text':
            if m['tag'] not in TEXT_TAGS: return None, '%s: a text block is one of %s' % (i, ', '.join(sorted(TEXT_TAGS)).lower())
            if m['children']: return None, '%s: a text block holds only its text (no child elements)' % i
            if not m['ink']: return None, '%s: its text must be painted (opacity 1, no filter, clip, mask or clear color, not clipped)' % i
            lines, canon = m['lines'], raw['canon']
            if not lines: return None, '%s: no rendered text' % i
            if min(l[3] for l in lines) < canon['h'] - 0.5: return None, '%s: every text line must be full size (%.1f px)' % (i, canon['h'])
            tops = sorted({round(l[1] * 2) / 2 for l in lines})
            if any(b - a < 23.5 for a, b in zip(tops, tops[1:])): return None, '%s: text lines must be at least 24 px apart' % i
            if sum(l[2] for l in lines) < m['natural'] - (len(tops) - 1) * canon['space'] - 1.5:
                return None, '%s: the text is set narrower than the standard font sets it' % i
            ink = m.get('ink_lines')
            if not ink or any(v is None or v < INK for v in ink): return None, '%s: every line of text must be clearly visible' % i
            if m['text'] != ' '.join(b['text'].split()): return None, '%s: the visible text must be exactly the article text' % i
            if m['overflow']: return None, '%s: its text overflows the block' % i
            font = m['font']
            first = font[2].split(',')[0].strip().strip('"\'')
            if first != 'DejaVu Sans' or any(f is not None and font[k] != f for k, f in enumerate(FONT)) or len(m['type']) != len(TYPE) or any(v not in ok for v, ok in zip(m['type'], TYPE)):
                return None, '%s: text must be 16px/24px "DejaVu Sans", weight 400, normal style, spacing, indent, case and breaking' % i
        elif b['kind'] == 'image':
            if abs(m['w'] / m['h'] - b['ratio']) > 0.01 * b['ratio']: return None, '%s: keep the aspect ratio %.4f' % (i, b['ratio'])
            if not b['min'] - 0.5 <= m['w'] <= b['max'] + 0.5: return None, '%s: width must be %d..%d px' % (i, b['min'], b['max'])
        elif abs(m['w'] - b['w']) > 0.5 or abs(m['h'] - b['h']) > 0.5: return None, '%s: an ad is exactly %dx%d px' % (i, b['w'], b['h'])
        boxes.append((i, m['x'], m['y'], m['x'] + m['w'], m['y'] + m['h']))
    for a in range(len(boxes)):
        for c in range(a + 1, len(boxes)):
            p, q = boxes[a], boxes[c]
            if min(p[3], q[3]) - max(p[1], q[1]) > 0.5 and min(p[4], q[4]) - max(p[2], q[2]) > 0.5:
                return None, 'blocks %s and %s overlap' % (p[0], q[0])
    return round(max(x[4] for x in boxes), 2), None
