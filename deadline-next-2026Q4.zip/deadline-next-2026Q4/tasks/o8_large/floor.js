function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function solve(page) {
  // One column, in the given order: every block at its widest allowed size.
  let h = '<!doctype html><html><head><style>body{margin:0}.t{font:16px/24px "DejaVu Sans";margin:0}</style></head>' +
          '<body><div style="width:' + page.width + 'px">';
  for (const b of page.blocks) {
    if (b.kind === 'text') h += '<p class="t" data-dl="' + b.id + '">' + esc(b.text) + '</p>';
    else if (b.kind === 'image') h += '<div data-dl="' + b.id + '" style="width:' + b.max + 'px;height:' + (b.max / b.ratio) + 'px"></div>';
    else h += '<div data-dl="' + b.id + '" style="width:' + b.w + 'px;height:' + b.h + 'px"></div>';
  }
  return h + '</div></body></html>';
}
module.exports = {solve};
