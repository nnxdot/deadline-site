def solve(events):
    """FIFO stock ledger. events: ["buy", item, qty, price] | ["sell", item, qty, price] | ["audit", item].
    A sell takes from the oldest lots first; what cannot be covered is ignored. Each audit reports
    [quantity held, value held at purchase prices, trades of this item so far, realized profit so far (all items)]."""
    lots = {}
    realized = 0
    history = []
    out = []
    for e in events:
        history.append(e)
        if e[0] == 'buy':
            lots.setdefault(e[1], []).append([e[2], e[3]])
        elif e[0] == 'sell':
            book, qty = lots.get(e[1], []), e[2]
            while qty > 0 and book:
                take = min(qty, book[0][0])
                realized += take * (e[3] - book[0][1])
                book[0][0] -= take
                qty -= take
                if book[0][0] == 0:
                    book.pop(0)
        else:
            held = value = 0
            for lot in lots.get(e[1], []):
                held += lot[0]
                value += lot[0] * lot[1]
            trades = sum(1 for h in history if h[0] != 'audit' and h[1] == e[1])
            out.append([held, value, trades, realized])
    return out
