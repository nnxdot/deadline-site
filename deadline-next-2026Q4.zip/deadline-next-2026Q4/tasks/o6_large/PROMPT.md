# O6 · Fast code · Shortest paths under edits

`slow.py` is correct but slow. Write `answers/solution.py` with a `solve` function that returns EXACTLY the same output
as `slow.solve` for every input made like the examples, using as little CPU time as you can.

## Score
For each of 30 hidden inputs:
- `floor` is the CPU time of `slow.py`.
- `ref` is the CPU time of our faster rewrite.
- `you` is your CPU time.

All three are measured by the grader in the same sandbox, in the same way.

The rules:
- Any output different from `slow.solve`'s, an exception, a blocked call, or a group running out of time scores -0.15.
- Otherwise the score is `log(floor/you) / log(floor/ref)`, never below -0.15. Submitting `slow.py` unchanged scores
  about 0, matching our rewrite scores 1, and faster scores more. There is no maximum.
- The task score is the mean over the hidden inputs. They are made the same way as the examples, and they are minted
  only after your run ends.

## How CPU time is measured
- Each input runs in a fresh process: it imports your module, calls `solve` once, and sends the result as JSON.
  The kernel measures that process's CPU time (user + system), import included.
- The CPU time of an empty module (`def solve(x): return 0`) measured the same way is subtracted. A cost below
  0.2 ms counts as 0.2 ms.
- This runs 3 times, each time in a fresh sandbox. Every run must give the same output; the smallest CPU time counts.
  Nothing carries over from one run to the next.
- Use Python 3.12, standard library only, one CPU and 512 MB of memory. There is no network.
- Your process cannot start other processes or threads, and it cannot write file data. Work that tries fails.
- Inputs run in groups of 10. A group has 180 seconds of wall time per run. A group that runs out of
  time makes all of its inputs invalid.
- Your output passes through JSON, so tuples become lists. Types must match exactly: `True` is not `1`, and `1.0` is
  not `1`.

## Tools in this folder
- `slow.py` is the specification: correct and slow.
- `check.py` runs your module and `slow.py` on `examples.json`, checks that the outputs are the same, and prints local
  times and an estimated score. Your local machine differs from the grader's, so local times are only a guide.
- `examples.json` holds public inputs, each with the grader-measured `floor` and `ref` CPU seconds.
