import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

"""python check.py [answers/solution.py]: runs your module and slow.py on every example, checks the outputs are equal,
and prints local times (best of 3 plus the import, wall clock: many systems time CPU only coarsely) and an estimated score. Your machine is not the grader's,
so treat local times as a guide; the score uses the grader's own measurements."""
import copy, importlib.util, json, sys, time
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    t = time.perf_counter(); spec.loader.exec_module(m); return m, time.perf_counter() - t
def best(fn, x, reps=3):
    out, top = None, None
    for k in range(reps):
        arg = copy.deepcopy(x); t = time.perf_counter(); v = fn(arg); t = time.perf_counter() - t
        if k == 0: out = json.loads(json.dumps(v, allow_nan=False))
        top = t if top is None or t < top else top
    return out, top
mine, load_cpu = load(sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py', 'candidate')
slow, _ = load('slow.py', 'slow')
scores = []
for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
    want, slow_cpu = best(slow.solve, e['input'], 1)
    try: got, cpu = best(mine.solve, e['input'])
    except Exception as exc: got, cpu = None, None; print('example %d: error %s' % (i, type(exc).__name__))
    canon = lambda v: json.dumps(v, sort_keys=True, allow_nan=False)
    ok = got is not None and canon(got) == canon(want)
    you = max(2e-4, cpu + load_cpu) if ok else None
    # Local times differ from the grader's: scale your time by the ratio of the grader's slow time to the local one.
    scaled = you * e['floor'] / slow_cpu if ok and slow_cpu > 0 else None
    s = score(e['floor'], e['ref'], scaled); scores.append(s)
    print('example %d: %s, local slow %.3fs, local you %s, grader floor %.3fs, ref %.3fs, estimated score %.3f'
          % (i, 'same output' if ok else 'DIFFERENT OUTPUT', slow_cpu, '%.4fs' % cpu if cpu is not None else '-', e['floor'], e['ref'], s))
print('mean estimated score %.3f' % (sum(scores) / len(scores)))
