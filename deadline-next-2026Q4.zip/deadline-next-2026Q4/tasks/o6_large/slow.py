def solve(task):
    """Shortest paths under edits. task: {"n": nodes, "edges": [[u, v, w]], "ops": [...]}; directed edges, w >= 0.
    op ["set", u, v, w] adds or changes edge u->v (w = -1 removes it); op ["path", s, t] reports the shortest
    distance from s to t, or -1 if t cannot be reached."""
    n = task['n']
    edges = {(u, v): w for u, v, w in task['edges']}
    out = []
    for op in task['ops']:
        if op[0] == 'set':
            edges[(op[1], op[2])] = op[3]
            continue
        nbrs = [[] for _ in range(n)]
        for (u, v), w in edges.items():
            if w >= 0:
                nbrs[u].append((v, w))
        dist = [None] * n
        done = [False] * n
        dist[op[1]] = 0
        for _ in range(n):
            u = None
            for x in range(n):
                if not done[x] and dist[x] is not None and (u is None or dist[x] < dist[u]):
                    u = x
            if u is None:
                break
            done[u] = True
            for v, w in nbrs[u]:
                if dist[v] is None or dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
        out.append(-1 if dist[op[2]] is None else dist[op[2]])
    return out
