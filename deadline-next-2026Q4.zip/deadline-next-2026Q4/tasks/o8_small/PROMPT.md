# O8 · Page layout · small

Write `answers/solution.js`: `solve(page)` returns one HTML document that lays out every block on a page 900 px wide.
Make the page as SHORT as you can while following every rule. A real Chrome renders your HTML and measures it.

## Score
For each hidden page:
- `you` = the bottom (in CSS px) of the lowest block.
- `floor` = the same for the one-column layout, `floor.js`.
- `ref` = the same for the best of our multi-column layouts, each measured in the same Chrome.

The rules:
- A broken rule, an exception, a non-string result, HTML over 1000000 characters, or a group out of time scores -0.15.
- Otherwise the score is `log(floor/you) / log(floor/ref)`, never below -0.15. One column scores 0, our layouts score
  1, and shorter scores more. There is no maximum.
- The task score is the mean over 30 hidden pages. They are made the same way as the examples, and they are minted
  only after your run ends.

## Input
`page` = `{"width": 900, "blocks": [...]}`, in no particular order. Each block is one of:
- `{"id":"a3","kind":"text","text":"..."}`: an article.
- `{"id":"i2","kind":"image","ratio":r,"min":lo,"max":hi}`: a picture box. Its width/height must stay r, and its
  width must be lo..hi.
- `{"id":"d1","kind":"ad","w":w,"h":h}`: an ad box of exactly w x h.

Each page has 7..9 articles, 2..4 images and 1..2 ads.

## Rules (checked on Chrome's measurement, with 0.5 px tolerance)
1. Every block is exactly one element with `data-dl="<id>"`. No other element has `data-dl`.
2. Every block lies inside the page: x >= 0, x + width <= 900, y >= 0. The document is no wider than 900 px.
3. No two blocks overlap. A block's box is its element's bounding rectangle: an article that wraps around a float or
   splits across columns covers its whole rectangle, so keep floats and columns outside articles.
4. An article element is a `div`, `p`, `span`, `section`, `article`, `aside`, `blockquote`, `li`, `figcaption`,
   `header`, `footer` or `main`, and holds only its text, with no child elements. Its visible text (`innerText`,
   whitespace collapsed) is exactly the article text.
5. The text is set in `16px/24px "DejaVu Sans"` (the first family), weight 400, normal style, stretch, spacing,
   indent, case and variant. These stay at their defaults: `font-size-adjust`, `font-kerning`, `font-feature-settings`,
   `font-variation-settings`, `word-break`, `overflow-wrap`, `hyphens`, `line-break`, `text-rendering`, `direction`
   and `unicode-bidi`. No stylesheet rule (imported ones included) may use `::first-line` or `::first-letter`.
   Chrome's rendering is checked too: every rendered line is as tall as the standard font's line box, lines are at
   least 24 px apart, and the text is as wide as the same text set in the standard font.
6. The text must not overflow its element in height or width. It must be painted: on the article and its ancestors,
   opacity 1 and no `filter`, `clip-path`, `mask` or `clip`; its color is not transparent; no ancestor's `overflow`
   clips it. Chrome takes two screenshots, one as rendered and one with every block hidden: on every line of text, at
   least 5% of the pixels must change clearly. Text that is covered, faint, or the color of its background fails.
7. Images keep their ratio within 1% and their width range. Ads are exactly their size.
8. No block, and no ancestor of a block, may have a transform, scale, rotate, translate or zoom. Every ancestor of a
   block is `html`, `body`, an element from rule 4, `nav`, `ul`, `ol`, `figure`, or a table element. Web fonts
   (`@font-face`) are not allowed.

## Sandbox
- `solve` runs in Node 22 (no browser, no network), in groups of 10 pages with 60 seconds per group.
- Chrome then renders each page 900 px wide with scripts disabled and all network requests blocked. `data:` URLs
  still work, but web fonts are banned by rule 8.
- `validate.py` is the grader's exact rule check, applied to Chrome's measurement (`measure_next.cjs`).
- The grader's Chrome has the DejaVu fonts (fonts-dejavu-core). Your own machine may not have them, so local text
  heights can differ.

## Tools in this folder
- `floor.js` is the one-column layout.
- `examples.json` holds public pages, each with its grader-measured `floor` and `ref` and our best layout `ref_html`.
- `check.py` runs `solve` with Node, and measures the result in a local Chrome or Edge if it finds one.
  Fonts may differ from the grader's, so treat its numbers as a guide.
