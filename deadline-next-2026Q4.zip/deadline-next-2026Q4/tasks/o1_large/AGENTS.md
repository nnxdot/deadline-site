Solve the one task in PROMPT.md. Save answers/solution.py early and keep it working: the last saved
version is graded, even if this run is stopped.

Limits for this run: 3,000,000 new tokens (input not served from the cache, plus output) and 60 minutes.
When either is used up, the run stops at once.
Work only in this folder. Do not use the network. You get one attempt and no feedback from the grader.
You may run Python here to test and score your solution with the tools listed in PROMPT.md.
