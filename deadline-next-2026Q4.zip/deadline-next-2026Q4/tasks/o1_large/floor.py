def _runs(s):
    out, x = [], 0
    for i, c in enumerate(s.split(',') if s else ()):
        c = int(c)
        if i % 2: out.append((x, x + c))
        x += c
    return out
def solve(target):
    """Boxes only: merge each row's filled runs along y into rectangles, then identical rectangles along z."""
    X, Y, Z = target['size']; rows = target['rows']
    slabs = []
    for z in range(Z):
        rects, open_ = [], {}
        for y in range(Y + 1):
            cur = set(_runs(rows[z * Y + y])) if y < Y else set()
            for r in list(open_):
                if r not in cur: rects.append((r, open_.pop(r), y))
            for r in cur: open_.setdefault(r, y)
        slabs.append(set(rects))
    boxes, open_ = [], {}
    for z in range(Z + 1):
        cur = slabs[z] if z < Z else set()
        for b in list(open_):
            if b not in cur: boxes.append((b, open_.pop(b), z))
        for b in cur: open_.setdefault(b, z)
    kids = [{'type': 'box', 'min': [x0, y0, z0], 'max': [x1, y1, z1]} for ((x0, x1), y0, y1), z0, z1 in sorted(boxes)]
    if len(kids) == 1: return kids[0]
    return {'type': 'union', 'children': kids or [{'type': 'box', 'min': [0, 0, 0], 'max': [0, 0, 0]}]}
