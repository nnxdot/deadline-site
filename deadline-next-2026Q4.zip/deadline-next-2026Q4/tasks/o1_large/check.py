MAX_NODES, MAX_DEPTH, MAX_EXPANDED = 400, 30, 2000
SCHEMA = {
    'box': {'min': 'vec', 'max': 'vec'},
    'sphere': {'center': 'vec', 'radius': 'pos'},
    'cylinder': {'axis': 'axis', 'center': 'vec', 'radius': 'pos', 'from': 'num', 'to': 'num'},
    'cone': {'axis': 'axis', 'center': 'vec', 'radius': 'pos', 'from': 'num', 'to': 'num'},
    'torus': {'axis': 'axis', 'center': 'vec', 'major': 'pos', 'minor': 'pos'},
    'union': {'children': 'kids'}, 'difference': {'children': 'kids'}, 'intersection': {'children': 'kids'},
    'translate': {'by': 'vec', 'child': 'node'},
    'rotate': {'axis': 'axis', 'turns': 'turns', 'pivot': 'vec', 'child': 'node'},
    'reflect': {'axis': 'axis', 'at': 'num', 'child': 'node'},
    'mirror': {'axis': 'axis', 'at': 'num', 'child': 'node'},
    'array': {'count': 'count', 'step': 'vec', 'child': 'node'},
}
def _num(v):
    # The range test comes first, so huge ints, inf and nan never reach the arithmetic.
    return type(v) in (int, float) and -200 <= v <= 200 and v * 2 == int(v * 2)
def validate(node):
    """None if the tree follows every rule, else the first broken rule found.

    Expanded size: every node counts once per copy that the renderer evaluates; an array multiplies the count of
    everything below it by its count, a mirror by 2. It must stay <= MAX_EXPANDED."""
    seen, expanded, stack = 0, 0, [(node, 0, 1)]
    while stack:
        nd, d, copies = stack.pop()
        seen += 1; expanded += copies
        if seen > MAX_NODES: return 'more than %d nodes' % MAX_NODES
        if expanded > MAX_EXPANDED: return 'expanded size above %d' % MAX_EXPANDED
        if d > MAX_DEPTH: return 'deeper than %d below the root' % MAX_DEPTH
        if type(nd) is not dict or type(nd.get('type')) is not str or nd['type'] not in SCHEMA: return 'unknown node type'
        fields = SCHEMA[nd['type']]
        if nd['type'] == 'array' and type(nd.get('count')) is int and 0 <= nd['count'] <= 12: inner = copies * nd['count']
        elif nd['type'] == 'mirror': inner = copies * 2
        else: inner = copies
        if set(nd) != set(fields) | {'type'}: return nd['type'] + ': fields must be exactly ' + ', '.join(sorted(fields))
        for name, kind in fields.items():
            v = nd[name]
            if kind == 'vec': ok = type(v) is list and len(v) == 3 and all(_num(x) for x in v)
            elif kind == 'num': ok = _num(v)
            elif kind == 'pos': ok = _num(v) and v > 0
            elif kind == 'axis': ok = type(v) is str and v in ('x', 'y', 'z')
            elif kind == 'turns': ok = type(v) is int and -8 <= v <= 8
            elif kind == 'count': ok = type(v) is int and 0 <= v <= 12
            elif kind == 'kids':
                ok = type(v) is list and len(v) >= 1
                if ok: stack.extend((k, d + 1, inner) for k in v)
            else:
                ok = True
                stack.append((v, d + 1, inner))
            if not ok: return nd['type'] + '.' + name + ': bad value'
        if nd['type'] == 'cone' and not nd['from'] < nd['to']: return 'cone: from must be < to'
    return None
def count(node):
    """Node count of a valid tree, the root included."""
    total, stack = 0, [node]
    while stack:
        nd = stack.pop(); total += 1
        stack.extend(nd.get('children') or ([nd['child']] if 'child' in nd else []))
    return total
import math
PENALTY = -0.15
def score(floor, ref, you):
    """floor scores 0, ref scores 1, smaller than ref scores above 1; invalid (None) and worse-than-floor floor at -0.15."""
    if you is None: return PENALTY
    return max(PENALTY, math.log(floor / you) / math.log(floor / ref))
MAX_DEPTH = 200
def too_deep(v):
    """True if an answer is nested deeper than MAX_DEPTH (the grader rejects such answers)."""
    stack = [(v, 1)]
    while stack:
        x, d = stack.pop()
        if d > MAX_DEPTH: return True
        if isinstance(x, dict): stack.extend((y, d + 1) for y in x.values())
        elif isinstance(x, (list, tuple)): stack.extend((y, d + 1) for y in x)
    return False

import json
from render import solve as render
def check(target, node):
    """(node count, None) if node renders to exactly target and follows every rule, else (None, reason).

    The answer first makes the same JSON round trip as in the grader, so tuples become lists and nan is rejected."""
    if too_deep(node): return None, 'answer nested deeper than %d' % MAX_DEPTH
    try: node = json.loads(json.dumps(node, allow_nan=False))
    except (TypeError, ValueError, RecursionError): return None, 'not JSON data'
    try:
        why = validate(node)
        if why: return None, why
        grid = render({'size': target['size'], 'root': node})
    except Exception as exc: return None, 'checker error: ' + type(exc).__name__
    return (count(node), None) if grid['rows'] == target['rows'] else (None, 'wrong grid')
if __name__ == '__main__':
    import importlib.util, json, sys, time
    path = sys.argv[1] if len(sys.argv) > 1 else 'answers/solution.py'
    spec = importlib.util.spec_from_file_location('candidate', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    scores = []
    for i, e in enumerate(json.load(open('examples.json', encoding='utf-8'))):
        started = time.monotonic()
        try: nodes, why = check(e['target'], module.solve(json.loads(json.dumps(e['target']))))  # a copy, as in the grader
        except Exception as exc: nodes, why = None, 'error: ' + type(exc).__name__
        s = score(e['floor'], e['ref'], nodes); scores.append(s)
        print('example %d: floor %d, ref %d, you %s, score %.3f, %.1fs%s' % (i, e['floor'], e['ref'], nodes, s,
              time.monotonic() - started, '' if nodes else ' (' + why + ')'))
    print('mean score %.3f' % (sum(scores) / len(scores)))
