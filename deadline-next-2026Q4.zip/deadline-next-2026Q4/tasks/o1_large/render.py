from math import isqrt
AX={'x':0,'y':1,'z':2}
def dbl(v):
    w=v*2
    if w!=int(w):raise ValueError('coordinate is not a multiple of 0.5')
    return int(w)
def rinv(v,a,k):
    v=list(v);b,c=(a+1)%3,(a+2)%3
    for _ in range((-k)%4):v[b],v[c]=-v[c],v[b]
    return v
def norm(iv):
    out=[]
    for a,b in sorted(iv):
        if a>=b:continue
        if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
        else:out.append([a,b])
    return out
def inter(A,B):
    out=[];i=j=0
    while i<len(A) and j<len(B):
        a=max(A[i][0],B[j][0]);b=min(A[i][1],B[j][1])
        if a<b:out.append([a,b])
        if A[i][1]<B[j][1]:i+=1
        else:j+=1
    return out
def minus(A,B):
    out=[]
    for a,b in A:
        cur=a
        for c,d in B:
            if d<=cur or c>=b:continue
            if c>cur:out.append([cur,c])
            cur=max(cur,d)
        if cur<b:out.append([cur,b])
    return out
def span(lo,hi,base,s,n):
    if lo>hi:return []
    if s>0:a=-((base-lo)//s);b=(hi-base)//s
    else:a=-((hi-base)//-s);b=(base-lo)//-s
    a=max(a,0);b=min(b,n-1)
    return [[a,b+1]] if a<=b else []
def axis_of(d):
    for j in range(3):
        if d[j]:return j
def leaf(nd,base,d,n):
    t=nd['type'];A=axis_of(d);s=d[A]
    if t=='box':
        mn=[dbl(v) for v in nd['min']];mx=[dbl(v) for v in nd['max']]
        if any(not mn[j]<=base[j]<mx[j] for j in range(3) if j!=A):return []
        return span(mn[A],mx[A]-1,base[A],s,n)
    if t=='sphere':
        c=[dbl(v) for v in nd['center']];r=dbl(nd['radius'])
        K=r*r-sum((base[j]-c[j])**2 for j in range(3) if j!=A)
        if K<0:return []
        q=isqrt(K);return span(c[A]-q,c[A]+q,base[A],s,n)
    X=AX[nd['axis']];c=[dbl(v) for v in nd['center']]
    if t=='cylinder':
        r=dbl(nd['radius']);lo=dbl(nd['from']);hi=dbl(nd['to'])
        if A==X:
            if sum((base[j]-c[j])**2 for j in range(3) if j!=X)>r*r:return []
            return span(lo,hi-1,base[A],s,n)
        if not lo<=base[X]<hi:return []
        J=3-A-X;K=r*r-(base[J]-c[J])**2
        if K<0:return []
        q=isqrt(K);return span(c[A]-q,c[A]+q,base[A],s,n)
    if t=='cone':
        R=dbl(nd['radius']);lo=dbl(nd['from']);hi=dbl(nd['to']);h=hi-lo
        if A==X:
            D=sum((base[j]-c[j])**2 for j in range(3) if j!=X);q=D*h*h;w=max(1,isqrt(q//(R*R)))
            while R*R*w*w<q:w+=1
            while w>1 and R*R*(w-1)*(w-1)>=q:w-=1
            return span(lo,min(hi-1,hi-w),base[A],s,n)
        if not lo<=base[X]<hi:return []
        J=3-A-X;N=R*R*(hi-base[X])**2-(base[J]-c[J])**2*h*h
        if N<0:return []
        q=isqrt(N//(h*h));return span(c[A]-q,c[A]+q,base[A],s,n)
    if t=='torus':
        M=dbl(nd['major']);m=dbl(nd['minor'])
        reach=m if A==X else M+m
        out=[]
        for t0 in (span(c[A]-reach,c[A]+reach,base[A],s,n) or [[0,0]]):
            for i in range(t0[0],t0[1]):
                p=list(base);p[A]=base[A]+s*i
                W=(p[X]-c[X])**2;P=sum((p[j]-c[j])**2 for j in range(3) if j!=X);T=P+M*M+W-m*m
                if T<=0 or 4*M*M*P>=T*T:out.append([i,i+1])
        return norm(out)
    raise ValueError('unknown node type')
def ev(nd,base,d,n):
    t=nd['type']
    if t in ('box','sphere','cylinder','cone','torus'):return leaf(nd,base,d,n)
    if t=='translate':
        return ev(nd['child'],[base[j]-dbl(nd['by'][j]) for j in range(3)],d,n)
    if t=='rotate':
        a=AX[nd['axis']];pv=[dbl(v) for v in nd['pivot']]
        b=rinv([base[j]-pv[j] for j in range(3)],a,nd['turns'])
        return ev(nd['child'],[b[j]+pv[j] for j in range(3)],rinv(d,a,nd['turns']),n)
    if t in ('reflect','mirror'):
        a=AX[nd['axis']];b=list(base);e=list(d);b[a]=2*dbl(nd['at'])-b[a];e[a]=-e[a]
        flipped=ev(nd['child'],b,e,n)
        return flipped if t=='reflect' else norm(flipped+ev(nd['child'],base,d,n))
    if t=='array':
        out=[]
        for k in range(nd['count']):
            out+=ev(nd['child'],[base[j]-k*dbl(nd['step'][j]) for j in range(3)],d,n)
        return norm(out)
    kids=nd['children']
    if t=='union':
        out=[]
        for k in kids:out+=ev(k,base,d,n)
        return norm(out)
    if t=='intersection':
        out=ev(kids[0],base,d,n)
        for k in kids[1:]:
            if not out:break
            out=inter(out,ev(k,base,d,n))
        return out
    if t=='difference':
        out=ev(kids[0],base,d,n)
        cut=[]
        for k in kids[1:]:cut+=ev(k,base,d,n)
        return minus(out,norm(cut))
    raise ValueError('unknown node type')
def solve(scene):
    X,Y,Z=scene['size'];rows=[];filled=0
    for z in range(Z):
        for y in range(Y):
            iv=ev(scene['root'],[1,2*y+1,2*z+1],[2,0,0],X);prev=0;runs=[]
            for a,b in iv:runs+=[a-prev,b-a];prev=b;filled+=b-a
            rows.append(','.join(map(str,runs)))
    return {'size':[X,Y,Z],'filled':filled,'rows':rows}
