# O1 · Shape to recipe · small

You get a voxel grid. Return a scene tree that renders to EXACTLY that grid, with as few nodes as you can.

## Score
For each hidden target:
- `floor` is the node count of the simple boxes-only answer, `floor.py`.
- `ref` is the node count of our reference recipe.
- `you` is your node count.

The rules:
- An invalid answer scores -0.15. Invalid means any cell differs, any tree rule below is broken, `solve` raises, or
  your group of targets runs out of time.
- A valid answer scores `log(floor/you) / log(floor/ref)`, but never below -0.15. The floor scores 0 and the reference
  scores 1. Smaller than the reference scores above 1. There is no maximum.
- The task score is the mean over 30 hidden targets. They are made the same way as `examples.json`, and they are
  minted only after your run ends.

## Interface
- Write `answers/solution.py` with `solve(target)`, and return the root node (a dict).
- `target` is `{"size":[X,Y,Z],"rows":[...]}`.
- `rows` is ONE FLAT LIST of Y*Z strings. The string for line (y,z) is `rows[z*Y + y]`. Each string is the run-length
  format described below.
- The node count is every node in the tree, the root included.
- Use the Python 3.12 standard library only, with no network, one CPU and 512 MB of memory.
- Hidden targets run in groups of 10, each group in one process with 50 seconds. A group that runs
  out of time makes all 10 of its targets invalid.
- Every side of every hidden grid (X, Y and Z) is in 12..16.
- Your answer passes through JSON on its way to the grader, so tuples arrive as lists. `check.py` does the same round trip.

Tree rules (`check.py` enforces exactly these):
- At most 400 nodes, and depth at most 30 below the root.
- Expanded size at most 2000. Every node counts once per copy the renderer evaluates: an `array` multiplies the count
  of everything below it by its `count`, and a `mirror` by 2.
- Only the node types below, each with exactly its listed fields and no others.
- Every number is an int or float (not a boolean), a multiple of 0.5, within +-200.
- `turns` is an int within +-8.
- Array `count` is an int 0..12.
- `children` is a non-empty list.
- `radius`, `major` and `minor` are > 0.
- For a cone, `from` < `to`.

## Tools in this folder
- `render.py` is the exact renderer the grader uses.
- `check.py` is the exact checker and scorer. `python check.py` runs `answers/solution.py` on `examples.json` and
  prints each score.
- `floor.py` makes the floor answer.
- `examples.json` holds public targets, each with `floor`, `ref` and our reference recipe `ref_tree`.

## What render.py computes (scene language and grid format)
Write a voxel solid modeler. The input is a scene {"size":[X,Y,Z],"root":node}. The grid has
X*Y*Z unit cells; cell (x,y,z) with 0<=x<X etc. spans [x,x+1) x [y,y+1) x [z,z+1). A cell is FILLED
iff its center (x+0.5, y+0.5, z+0.5) is inside the root solid. Geometry may extend outside the grid;
only grid cells are reported. Every coordinate, length and offset in a scene is a multiple of 0.5.
"Inside" tests are exact real arithmetic (work in doubled coordinates to stay in integers).

Node types (all fields always present):
- {"type":"box","min":[x,y,z],"max":[x,y,z]}: points with min<=p<max on every axis (half-open; min may equal or exceed max on an axis, giving an empty box).
- {"type":"sphere","center":[x,y,z],"radius":r}: points with |p-center|<=r (closed). r>0.
- {"type":"cylinder","axis":"x"|"y"|"z","center":[x,y,z],"radius":r,"from":a,"to":b}: along the axis, a<=p_axis<b (half-open); across it, the squared distance from p to the axis line through center is <=r^2 (closed). r>0. The center's own axis component is ignored.
- {"type":"cone","axis":...,"center":[x,y,z],"radius":R,"from":a,"to":b}: a<=p_axis<b (half-open) and distance to the axis line <= R*(b-p_axis)/(b-a) (closed): radius R at "from", apex at "to". a<b, R>0. The center's axis component is ignored.
- {"type":"torus","axis":...,"center":[x,y,z],"major":M,"minor":m}: points whose distance to the circle of radius M around the axis line through center, in the plane p_axis=center_axis, is <=m (closed): (sqrt(d^2)-M)^2+(p_axis-center_axis)^2<=m^2 where d is the distance to the axis line. M>0, m>0; m may exceed M. A float square root is not exact enough: boundary cells are tested.
- {"type":"union","children":[...]} (one or more children): inside any child.
- {"type":"difference","children":[first,...]} (one or more): inside first and inside no later child.
- {"type":"intersection","children":[...]} (one or more): inside every child.
- {"type":"translate","by":[dx,dy,dz],"child":node}: the child moved by (dx,dy,dz).
- {"type":"rotate","axis":...,"turns":k,"pivot":[x,y,z],"child":node}: the child rotated by k quarter turns about the axis line through pivot. k is any integer (negative = the other way; k and k+4 are equal). One positive turn about x maps relative coordinates (y,z) to (-z,y); about y maps (z,x) to (-x,z); about z maps (x,y) to (-y,x). A point is inside the rotated solid iff rotating it back puts it inside the child.
- {"type":"reflect","axis":...,"at":c,"child":node}: only the mirror image of the child across the plane p_axis=c. {"type":"mirror", same fields}: the child AND its mirror image (union).
- {"type":"array","count":n,"step":[dx,dy,dz],"child":node}: union of copies k=0..n-1, copy k moved by k*step. n is an integer >= 0; n=0 is empty.

Return {"size":[X,Y,Z],"filled":F,"rows":[...]} where F is the number of filled cells and rows has one
string per (y,z) line, ordered z outer, y inner (index z*Y+y). A row string run-length encodes x=0..X-1
as comma-separated counts that alternate empty, filled, empty, filled, ... starting with an EMPTY count
(which may be 0). Stop after the last filled run; every count after the first is positive; an all-empty
row is "". Example for X=8, cells 0,1 and 4..6 filled: "0,2,2,3".

Bounds: 1<=X,Y,Z<=16; tree depth <= 30 below the root; at most 400 nodes; all coordinates
within +-200. turns within +-8; array count <= 12.
