"""DEADLINE Next community client. Python 3.10+ standard library only.

    python next_client.py list
    python next_client.py prepare --out myrun                    # fresh task folders ("rooms") to work in
    python next_client.py run-codex myrun --model M --effort E   # optional: run the Codex CLI in every room
    python next_client.py run-opencode myrun --model P/M         # optional: run opencode in every room
    python next_client.py usage myrun                            # tokens, cost and time per task
    python next_client.py check myrun                            # local scores on the public examples
    python next_client.py collect myrun --model M --effort E --harness H   # writes myrun/submission.zip

Run any agent you like in each room: it reads AGENTS.md and PROMPT.md and saves its answer in answers/. The official
limits per task are printed in AGENTS.md (a token budget and a 60-minute stop). Hidden test instances are made by the
maintainers only after you submit; nothing secret is in this package.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
FORMAT = 'deadline-next-submission-1'


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def load_manifest(): return json.loads((HERE / 'manifest.json').read_text(encoding='utf-8'))
def package_id(): return hashlib.sha256((HERE / 'manifest.json').read_bytes()).hexdigest()


def pick(manifest, ids):
    tasks = manifest['tasks']
    if not ids: return tasks
    known = {t['id']: t for t in tasks}
    missing = [i for i in ids if i not in known]
    if missing: sys.exit('unknown task ids: ' + ', '.join(missing))
    return [known[i] for i in ids]


def cmd_list(a):
    m = load_manifest()
    print('DEADLINE Next wave %s, %d tasks, budget %s new tokens and %d minutes per task' % (m['wave'], len(m['tasks']), f"{m['budget_tokens']:,}", m['wall_seconds'] // 60))
    for t in m['tasks']: print('  %-10s %-10s %s' % (t['id'], t['language'], t['title']))


def cmd_prepare(a):
    m = load_manifest(); out = Path(a.out).resolve()
    if out.exists() and any(out.iterdir()): sys.exit('%s is not empty; choose a new folder' % out)
    if HERE in out.parents or out == HERE: sys.exit('put the run folder outside the package folder')
    for t in pick(m, a.tasks):
        room = out / t['id'] / 'room'
        shutil.copytree(HERE / 'tasks' / t['id'], room)
        (room / 'answers').mkdir(exist_ok=True)
    (out / 'run.json').write_text(json.dumps({'wave': m['wave'], 'package': package_id(), 'created': now()}, indent=1), encoding='utf-8')
    print('prepared %d rooms in %s' % (len(pick(m, a.tasks)), out))
    print('In each <task>/room folder, start your agent with: "Read AGENTS.md and the entire PROMPT.md. Solve this one task."')


def rooms(run, manifest, ids):
    for t in pick(manifest, ids):
        room = Path(run) / t['id'] / 'room'
        if room.is_dir(): yield t, room


def cmd_check(a):
    m = load_manifest()
    for t, room in rooms(a.run, m, a.tasks):
        answer = room / t['answer_file']
        if not answer.is_file(): print('%-10s no answer yet' % t['id']); continue
        done = subprocess.run([sys.executable, t['tool']], cwd=room, capture_output=True, text=True, encoding='utf-8', timeout=a.timeout)
        lines = (done.stdout or done.stderr).strip().splitlines()
        print('%-10s %s' % (t['id'], lines[-1] if lines else 'no output'))


# ---------- optional Codex driver: same limits as official runs ----------

def codex_exe():
    found = os.environ.get('DEADLINE_CODEX') or shutil.which('codex')
    candidates = [found] if found else []
    candidates.append(str(Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs/OpenAI/Codex/bin/codex.exe'))
    for c in candidates:
        if c and Path(c).is_file(): return c
    sys.exit('Codex CLI not found; set DEADLINE_CODEX to its path')


class Session:
    """Reads the live Codex session receipt for total token usage (as the official runner does)."""
    def __init__(self, events):
        self.events, self.path, self.offset, self.usage, self.contexts = events, None, 0, None, []
        self.home = Path(os.environ.get('CODEX_HOME') or Path.home() / '.codex')

    def poll(self):
        if self.path is None:
            thread = None
            if self.events.exists():
                for line in self.events.read_text(encoding='utf-8', errors='replace').splitlines():
                    try: e = json.loads(line)
                    except ValueError: continue
                    if e.get('type') == 'thread.started': thread = e['thread_id']; break
            if not thread: return
            found = sorted((self.home / 'sessions').rglob('*' + thread + '.jsonl'), key=lambda p: p.stat().st_mtime)
            if not found: return
            self.path = found[-1]
        with self.path.open('rb') as f:
            f.seek(self.offset); data = f.read()
        end = data.rfind(b'\n') + 1; self.offset += end
        for line in data[:end].decode('utf-8', errors='replace').splitlines():
            try: e = json.loads(line)
            except ValueError: continue
            p = e.get('payload', {})
            if e.get('type') == 'turn_context': self.contexts.append({k: p.get(k) for k in ('model', 'effort')})
            elif e.get('type') == 'event_msg' and p.get('type') == 'token_count':
                total = (p.get('info') or {}).get('total_token_usage')
                if total: self.usage = total

    def total(self):
        """Every token, cached re-reads included (recorded, not budgeted)."""
        u = self.usage or {}
        return u.get('total_tokens', u.get('input_tokens', 0) + u.get('output_tokens', 0))

    def used(self):
        """The budgeted count: new tokens, i.e. input not served from the cache, plus output (reasoning included)."""
        u = self.usage or {}
        return max(0, u.get('input_tokens', 0) - u.get('cached_input_tokens', 0)) + u.get('output_tokens', 0)


def kill_tree(proc):
    if os.name == 'nt': subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
    else: proc.kill()


def cmd_run_codex(a):
    m = load_manifest(); exe = codex_exe()
    budget, wall = a.budget or m['budget_tokens'], a.wall or m['wall_seconds']
    for t, room in rooms(a.run, m, a.tasks):
        base = room.parent
        if (base / 'usage.json').exists(): print('%-10s already run, skipped' % t['id']); continue
        args = [exe, 'exec', '--ignore-user-config', '--model', a.model, '--config', f'model_reasoning_effort="{a.effort}"',
                '--config', 'approval_policy="never"', '--sandbox', 'workspace-write', '--config', 'sandbox_workspace_write.network_access=false',
                '--config', 'web_search="disabled"', '--skip-git-repo-check', '--cd', str(room), '--json', '--color', 'never',
                'Read AGENTS.md and the entire PROMPT.md. Solve this one task and save the complete final source as instructed. Work only in this folder.']
        if os.name == 'nt': args[args.index('--skip-git-repo-check'):args.index('--skip-git-repo-check')] = ['--config', 'windows.sandbox="unelevated"']
        events, session, started, stop = base / 'events.jsonl', None, time.monotonic(), None
        session = Session(events)
        with events.open('wb') as out, (base / 'stderr.log').open('wb') as err:
            proc = subprocess.Popen(args, cwd=room, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
            print('%-10s running (pid %d)' % (t['id'], proc.pid), flush=True)
            while proc.poll() is None:
                time.sleep(1); session.poll()
                if session.used() >= budget: stop = 'token_budget'
                elif time.monotonic() - started > wall: stop = 'wall_stop'
                elif session.usage is None and time.monotonic() - started > 60: stop = 'metering_failed'
                if stop: kill_tree(proc); proc.wait(); break
        session.poll()
        if not stop and session.used() >= budget: stop = 'token_budget'
        if not stop and session.usage is None: stop = 'metering_failed'
        record = {'status': stop or ('completed' if proc.returncode == 0 else 'cli_error'), 'harness': 'codex-cli', 'model': a.model,
                  'effort': a.effort, 'usage': session.usage, 'new_tokens': session.used(), 'total_tokens': session.total(), 'wall_seconds': round(time.monotonic() - started, 1),
                  'settings_seen': session.contexts[:3], 'finished_at': now()}
        (base / 'usage.json').write_text(json.dumps(record, indent=1), encoding='utf-8')
        print('%-10s %s, %s new tokens, %.0f s' % (t['id'], record['status'], f"{record['new_tokens']:,}", record['wall_seconds']), flush=True)
    print_usage(a.run, m, a.tasks)


# ---------- optional opencode driver: same limits, metered from its JSON event stream ----------

def opencode_exe():
    found = os.environ.get('DEADLINE_OPENCODE') or shutil.which('opencode')
    if found and Path(found).is_file(): return found
    sys.exit('opencode not found; set DEADLINE_OPENCODE to its path')


def opencode_flags(exe):
    """The options this opencode version's `run` command knows (they differ between versions)."""
    try: done = subprocess.run([exe, 'run', '--help'], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    except (OSError, subprocess.SubprocessError): return set()
    return set(re.findall(r'(--[a-z][a-z-]*)', done.stdout + done.stderr))


class Steps:
    """Reads `opencode run --format json` events as they arrive. Each step_finish event is one model call, with its
    tokens and its cost in dollars; the sums are the task's usage."""
    def __init__(self, events):
        self.events, self.offset, self.steps, self.session, self.errors = events, 0, 0, None, []
        self.tok = {'input': 0, 'output': 0, 'reasoning': 0, 'cache_read': 0, 'cache_write': 0}
        self.cost = 0.0

    def poll(self):
        if not self.events.exists(): return
        with self.events.open('rb') as f:
            f.seek(self.offset); data = f.read()
        end = data.rfind(b'\n') + 1; self.offset += end
        for line in data[:end].decode('utf-8', errors='replace').splitlines():
            try: e = json.loads(line)
            except ValueError: continue
            self.session = self.session or e.get('sessionID')
            if e.get('type') == 'error': self.errors.append(str((e.get('error') or {}).get('data', {}).get('message') or e.get('error'))[:300])
            if e.get('type') != 'step_finish': continue
            p = e.get('part') or {}; t = p.get('tokens') or {}; c = t.get('cache') or {}
            for k, v in (('input', t.get('input')), ('output', t.get('output')), ('reasoning', t.get('reasoning')),
                         ('cache_read', c.get('read')), ('cache_write', c.get('write'))):
                self.tok[k] += v or 0
            self.cost += p.get('cost') or 0
            self.steps += 1

    def used(self):
        """The budgeted count: new tokens. opencode reports input without cache reads; cache writes are new input,
        and reasoning is counted apart from output."""
        t = self.tok
        return t['input'] + t['cache_write'] + t['output'] + t['reasoning']

    def total(self): return self.used() + self.tok['cache_read']


def opencode_models(exe, session, env, v2, cwd):
    """The provider, model and variant opencode recorded for each answer, from the saved session."""
    cmd = [exe, 'session', 'export', '--standalone', session] if v2 else [exe, 'export', session]
    try:
        done = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', env=env, timeout=120, cwd=cwd)
        data = json.loads(done.stdout[done.stdout.find('{'):])
    except (OSError, ValueError, subprocess.SubprocessError): return []
    seen = []
    for msg in data.get('messages', []):
        if 'info' in msg:  # opencode 1.x
            i = msg['info'] or {}
            if i.get('role') != 'assistant': continue
            x = {'provider': i.get('providerID'), 'model': i.get('modelID'), 'variant': i.get('variant')}
        elif isinstance(msg.get('model'), dict):  # opencode 2.x
            x = {'provider': msg['model'].get('providerID'), 'model': msg['model'].get('id'), 'variant': msg['model'].get('variant')}
        else: continue
        if x not in seen: seen.append(x)
    return seen


def cmd_run_opencode(a):
    m = load_manifest(); exe = opencode_exe(); flags = opencode_flags(exe)
    budget, wall = a.budget or m['budget_tokens'], a.wall or m['wall_seconds']
    if '--format' not in flags:
        sys.exit('this opencode cannot report tokens while it works (its `run` has no --format json); update it')
    # opencode 2 runs through a background service unless --standalone; the private server it starts is ours to
    # stop, and it sees this process's settings. The variant (effort) goes on the model name: provider/model#variant.
    v2 = '--standalone' in flags
    if a.effort != 'default' and not v2 and '--variant' not in flags:
        sys.exit('this opencode has no --variant, so --effort cannot be set; update it, or leave --effort out')
    # No web, no files outside the room, no subagents or scripted tool calls (their tokens are not in this stream),
    # no questions to a user who is not there. Names cover opencode 1 and 2. Your own opencode config, plugins and
    # Claude Code files are left out unless you pass --keep-user-config.
    deny = ['webfetch', 'websearch', 'external_directory', 'task', 'subagent', 'execute', 'question', 'skill',
            'opencode.session_move', 'opencode.worktree_create', 'opencode.worktree_remove', 'opencode.worktree_list']
    config = {'share': 'disabled', 'autoupdate': False,
              'permission': dict({'edit': 'allow', 'bash': 'allow', 'shell': 'allow'}, **{k: 'deny' for k in deny})}
    env = dict(os.environ, OPENCODE_CONFIG_CONTENT=json.dumps(config))
    if not a.keep_user_config:
        empty = Path(a.run).resolve() / '.opencode-config'; empty.mkdir(parents=True, exist_ok=True)
        env.update(XDG_CONFIG_HOME=str(empty), OPENCODE_DISABLE_CLAUDE_CODE='1')
    for t, room in rooms(a.run, m, a.tasks):
        base = room.parent
        if (base / 'usage.json').exists(): print('%-10s already run, skipped' % t['id']); continue
        model = a.model + ('#' + a.effort if v2 and a.effort != 'default' else '')
        args = [exe, 'run', '--format', 'json', '--model', model]  # started inside the room, so no --dir
        if v2: args.append('--standalone')
        if not a.keep_user_config and '--pure' in flags: args.append('--pure')
        if a.effort != 'default' and not v2: args += ['--variant', a.effort]
        args.append('Read AGENTS.md and the entire PROMPT.md. Solve this one task and save the complete final source as instructed. Work only in this folder.')
        events, started = base / 'events.jsonl', time.monotonic()
        for attempt in (1, 2):  # opencode can crash while it starts; a crash before any event is retried once
            steps, stop = Steps(events), None
            with events.open('wb') as out, (base / 'stderr.log').open('wb') as err:
                proc = subprocess.Popen(args, cwd=room, stdin=subprocess.DEVNULL, stdout=out, stderr=err, env=env)
                print('%-10s running (pid %d)' % (t['id'], proc.pid), flush=True)
                while proc.poll() is None:
                    time.sleep(1); steps.poll()
                    if steps.used() >= budget: stop = 'token_budget'
                    elif time.monotonic() - started > wall: stop = 'wall_stop'
                    if stop: kill_tree(proc); proc.wait(); break
            steps.poll()
            if stop or steps.session or attempt == 2: break
            print('%-10s opencode stopped before it started (exit %s), trying again' % (t['id'], proc.returncode), flush=True)
            shutil.copyfile(base / 'stderr.log', base / 'stderr-first-try.log')
        if not stop and steps.used() >= budget: stop = 'token_budget'
        if not stop and steps.errors and proc.returncode != 0: stop = 'api_error'
        if not stop and not steps.steps: stop = 'metering_failed'
        record = {'status': stop or ('completed' if proc.returncode == 0 else 'cli_error'), 'harness': 'opencode', 'model': a.model,
                  'effort': a.effort, 'usage': dict(steps.tok, steps=steps.steps), 'new_tokens': steps.used(), 'total_tokens': steps.total(),
                  'cost_usd': round(steps.cost, 6), 'wall_seconds': round(time.monotonic() - started, 1),
                  'settings_seen': opencode_models(exe, steps.session, env, v2, room) if steps.session else [], 'errors': steps.errors[:3],
                  'finished_at': now()}
        (base / 'usage.json').write_text(json.dumps(record, indent=1), encoding='utf-8')
        print('%-10s %s, %s new tokens, $%.4f, %.0f s' % (t['id'], record['status'], f"{record['new_tokens']:,}", record['cost_usd'],
                                                       record['wall_seconds']), flush=True)
        if record['status'] == 'api_error': print('           ' + steps.errors[0], flush=True)
    print_usage(a.run, m, a.tasks)


def print_usage(run, m, ids):
    """Tokens, cost and time per task, from each room's usage.json, with totals."""
    rows = []
    for t, room in rooms(run, m, ids):
        f = room.parent / 'usage.json'
        if f.exists(): rows.append((t['id'], json.loads(f.read_text(encoding='utf-8'))))
    if not rows: print('no usage recorded yet'); return
    print('\n%-10s %-16s %12s %12s %10s %8s' % ('task', 'status', 'new tokens', 'all tokens', 'cost', 'minutes'))
    costs = [u.get('cost_usd') for _, u in rows]
    for tid, u in rows:
        cost = '$%.4f' % u['cost_usd'] if isinstance(u.get('cost_usd'), (int, float)) else '-'
        print('%-10s %-16s %12s %12s %10s %8.1f' % (tid, u.get('status'), f"{u.get('new_tokens') or 0:,}", f"{u.get('total_tokens') or 0:,}",
                                                    cost, (u.get('wall_seconds') or 0) / 60))
    total_cost = '$%.4f' % sum(costs) if all(isinstance(c, (int, float)) for c in costs) else '-'
    print('%-10s %-16s %12s %12s %10s %8.1f' % ('total', '%d tasks' % len(rows), f"{sum(u.get('new_tokens') or 0 for _, u in rows):,}",
                                                f"{sum(u.get('total_tokens') or 0 for _, u in rows):,}", total_cost,
                                                sum(u.get('wall_seconds') or 0 for _, u in rows) / 60))


def cmd_usage(a): print_usage(a.run, load_manifest(), a.tasks)


# ---------- submission ----------

def cmd_collect(a):
    m = load_manifest(); run = Path(a.run).resolve()
    info = json.loads((run / 'run.json').read_text(encoding='utf-8')) if (run / 'run.json').exists() else {}
    tasks, problems = {}, []
    for t, room in rooms(run, m, None):
        answer = room / t['answer_file']
        changed = sorted(name for name, h in t['files'].items() if not (room / name).is_file() or sha(room / name) != h)
        usage = json.loads((room.parent / 'usage.json').read_text(encoding='utf-8')) if (room.parent / 'usage.json').exists() else None
        if not answer.is_file(): problems.append(t['id'] + ': no answer'); continue
        # Bytes that are not UTF-8 (a Python file with its own coding line) are kept exactly, as surrogate escapes.
        body = answer.read_text(encoding='utf-8-sig', errors='surrogateescape')
        data = body.encode('utf-8', 'surrogateescape')
        if len(data) > 1_000_000: problems.append(t['id'] + ': answer over 1 MB'); continue
        tasks[t['id']] = {'answer': body, 'answer_sha256': hashlib.sha256(data).hexdigest(),
                          'room_files_changed': changed, 'usage': usage}
    submission = {'format': FORMAT, 'wave': m['wave'], 'package': package_id(), 'run_package': info.get('package'),
                  'model': a.model, 'effort': a.effort, 'harness': a.harness, 'submitted_by': a.name, 'created': now(),
                  'usage_verified': False, 'tasks': tasks}
    out = run / 'submission.zip'
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('submission.json', json.dumps(submission, indent=1))
    print('wrote %s: %d of %d tasks answered, sha256 %s' % (out, len(tasks), len(m['tasks']), sha(out)))
    for p in problems: print('  note: ' + p)
    if m.get('submit_url'): print('To submit, open an issue with the submission form and attach the zip: ' + m['submit_url'])
    changed = [i for i, x in tasks.items() if x['room_files_changed']]
    if changed: print('  note: task files were changed in ' + ', '.join(changed) + ' (recorded in the submission)')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='cmd', required=True)
    sub.add_parser('list')
    s = sub.add_parser('prepare'); s.add_argument('--out', required=True); s.add_argument('--tasks', nargs='+')
    s = sub.add_parser('check'); s.add_argument('run'); s.add_argument('--tasks', nargs='+'); s.add_argument('--timeout', type=int, default=900)
    s = sub.add_parser('run-codex'); s.add_argument('run'); s.add_argument('--model', required=True); s.add_argument('--effort', required=True)
    s.add_argument('--tasks', nargs='+'); s.add_argument('--budget', type=int); s.add_argument('--wall', type=int)
    s = sub.add_parser('run-opencode'); s.add_argument('run')
    s.add_argument('--model', required=True, help='provider/model, as in `opencode models`')
    s.add_argument('--effort', default='default', help='opencode --variant, e.g. high or max; default: the model default')
    s.add_argument('--tasks', nargs='+'); s.add_argument('--budget', type=int); s.add_argument('--wall', type=int)
    s.add_argument('--keep-user-config', action='store_true', help='use your own opencode config and plugins (needed for custom providers)')
    s = sub.add_parser('usage'); s.add_argument('run'); s.add_argument('--tasks', nargs='+')
    s = sub.add_parser('collect'); s.add_argument('run'); s.add_argument('--model', required=True); s.add_argument('--effort', required=True)
    s.add_argument('--harness', required=True, help='the agent you used, e.g. codex-cli, claude-code, custom')
    s.add_argument('--name', default=None, help='optional: your name or handle')
    a = p.parse_args()
    {'list': cmd_list, 'prepare': cmd_prepare, 'check': cmd_check, 'run-codex': cmd_run_codex, 'run-opencode': cmd_run_opencode,
     'usage': cmd_usage, 'collect': cmd_collect}[a.cmd](a)


if __name__ == '__main__': main()
