# DEADLINE Next, wave 2026Q4: community package

DEADLINE Next is a coding benchmark with no top score. Every answer must be correct, and better answers score higher.
This package holds the 24 public tasks, the exact checkers and scorers, and a small client.

## What you need
- Python 3.10 or newer (standard library only).
- Node.js 22 for the page layout tasks (`o8_*`), which are answered in JavaScript.
- For local page measurements (`o8_*` check.py): Chrome or Edge, and the DejaVu Sans font (package fonts-dejavu-core on
  Linux, or from dejavu-fonts.github.io). Without DejaVu Sans the browser uses another font, so local heights and
  scores differ from the grader's.
- An agent that can work in a folder: Codex CLI, Claude Code, or your own.

## Run
1. `python next_client.py list` shows the tasks.
2. `python next_client.py prepare --out ../myrun` makes a fresh copy of every task folder ("room").
3. In each `myrun/<task>/room`, start your agent with:
   "Read AGENTS.md and the entire PROMPT.md. Solve this one task and save the complete final source as instructed."
   Each room states its limits: 3,000,000 new tokens (input not served from the cache, plus output) and 60
   minutes per task.
   With the Codex CLI or opencode you can let the client do this, with the same limits:
   `python next_client.py run-codex ../myrun --model M --effort E` or
   `python next_client.py run-opencode ../myrun --model provider/model [--effort VARIANT]`.
   opencode has no sandbox: the client blocks web tools and files outside the room, but its shell can still reach them.
   `python next_client.py usage ../myrun` shows the tokens, cost (opencode only) and time of every task.
4. `python next_client.py check ../myrun` scores your answers on the public examples, on your own machine.
5. `python next_client.py collect ../myrun --model M --effort E --harness H` writes `myrun/submission.zip`.

## Submit
Open a GitHub issue with the submission form and attach `submission.zip`:
https://github.com/nnxdot/deadline-site/issues/new?template=next-submission.yml

The maintainers make fresh hidden instances for every task,
run your answers in their sandbox (no network, one CPU, 512 MB), and score them with the same code as official runs.
Community results are shown as community results; token counts you report are marked unverified.

## Rules
- One attempt per task. Do not look at other rooms, other runs, or the internet while solving.
- Do not change the files in a room except under `answers/`. Changes are detected and recorded.
- The scores in a room (from check.py or play.py) are estimates on public examples. Hidden instances decide the score.

Package a77058151306ee53fff2ff649e1bcc8460011b7c02c5a6953e5d709ea13f4bee
